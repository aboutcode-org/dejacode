Django REST Hooks is written and maintained by Zapier and
various contributors:


## Development Lead

- Bryan Helmig <bryan@zapier.com>


## Patches and Suggestions

- [Bryan Helmig](https://github.com/bryanhelmig)
- [Arnaud Limbourg](https://github.com/arnaudlimbourg)
- [tdruez](https://github.com/tdruez)
- [Maina Nick](https://github.com/mainanick)
- Jonathan Moss
- [Erik Wickstrom](https://github.com/erikcw)
- [Yaroslav Klyuyev](https://github.com/imposeren)
