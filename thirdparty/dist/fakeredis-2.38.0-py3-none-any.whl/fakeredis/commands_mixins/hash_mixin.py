from __future__ import annotations

import math
import random
from collections.abc import Sequence
from typing import Any, Callable, List, cast

from fakeredis import _msgs as msgs
from fakeredis._command_args_parsing import extract_args
from fakeredis._commands import CommandItem, Float, Int, Key, command
from fakeredis._helpers import OK, SimpleError, SimpleString, casematch, current_time
from fakeredis.commands_mixins._mixin_base import CommandsMixinBase
from fakeredis.model import Hash

# A hash field's TTL is capped more tightly still, and overshooting it is an error.
DRAGONFLY_MAX_HASH_EXPIRE_SECONDS = 2**26


class HashCommandsMixin(CommandsMixinBase):
    _encodeint: Callable[
        [
            int,
        ],
        bytes,
    ]
    _encodefloat: Callable[[float, bool], bytes]
    _scan: Callable[[Sequence[bytes], int, bytes], list[bytes | list[bytes]]]
    add_subkey_event: Callable[[bytes, bytes, Sequence[bytes]], None]

    def _hset(self, key: CommandItem, *args: bytes) -> int:
        h = key.value
        previous_keys_count = len(h)
        h.update(dict(zip(*[iter(args)] * 2)), clear_expiration=True)  # https://stackoverflow.com/a/12739974/1056460
        created = len(h) - previous_keys_count

        key.updated()
        self.add_subkey_event(b"hset", key.key, args[::2])
        return created

    @command((Key(Hash), bytes), (bytes,))
    def hdel(self, key: CommandItem, *fields: bytes) -> int:
        h = key.value
        deleted = []
        for field in fields:
            if field in h:
                del h[field]
                key.updated()
                deleted.append(field)
        self.add_subkey_event(b"hdel", key.key, deleted)
        return len(deleted)

    @command((Key(Hash), bytes))
    def hexists(self, key: CommandItem, field: bytes) -> int:
        return int(field in key.value)

    @command((Key(Hash), bytes))
    def hget(self, key: CommandItem, field: bytes) -> Any:
        return key.value.get(field)

    @command((Key(Hash),))
    def hgetall(self, key: CommandItem) -> dict[bytes, bytes]:
        hash_val: Hash = key.value
        return hash_val.getall()

    @command(fixed=(Key(Hash), bytes, bytes))
    def hincrby(self, key: CommandItem, field: bytes, amount_bytes: bytes) -> int:
        amount = Int.decode(amount_bytes)
        field_value = Int.decode(key.value.get(field, b"0"), decode_error=msgs.INVALID_HASH_MSG)
        c = field_value + amount
        key.value.update({field: self._encodeint(c)}, clear_expiration=False)
        key.updated()
        self.add_subkey_event(b"hincrby", key.key, (field,))
        return c

    @command((Key(Hash), bytes, bytes))
    def hincrbyfloat(self, key: CommandItem, field: bytes, amount: bytes) -> bytes | float:
        c = Float.decode(key.value.get(field, b"0")) + Float.decode(amount)
        if not math.isfinite(c):
            raise SimpleError(msgs.NONFINITE_MSG)
        encoded = self._encodefloat(c, True)
        key.value.update({field: encoded}, clear_expiration=False)
        key.updated()
        self.add_subkey_event(b"hincrbyfloat", key.key, (field,))
        # Redis replies with a bulk string, Dragonfly with a double.
        return c if self.server_type == "dragonfly" else encoded

    @command((Key(Hash),))
    def hkeys(self, key: CommandItem) -> list[bytes]:
        return list(key.value.keys())

    @command((Key(Hash),))
    def hlen(self, key: CommandItem) -> int:
        return len(key.value)

    @command((Key(Hash), bytes), (bytes,))
    def hmget(self, key: CommandItem, *fields: bytes) -> list[bytes]:
        return [key.value.get(field) for field in fields]

    @command((Key(Hash), bytes, bytes), (bytes, bytes))
    def hmset(self, key: CommandItem, *args: bytes) -> SimpleString:
        self.hset(key, *args)
        return OK

    @command((Key(Hash), Int), (bytes,))
    def hscan(self, key: CommandItem, cursor: int, *args: bytes) -> list[Any]:
        no_values = any(casematch(arg, b"novalues") for arg in args)
        scan_args = tuple(arg for arg in args if not casematch(arg, b"novalues")) if no_values else args
        scan_result = self._scan(key.value, cursor, *scan_args)
        result_cursor = scan_result[0]
        keys: list[bytes] = cast(List[bytes], scan_result[1])
        if no_values:
            return [result_cursor, keys]
        items = []
        for k in keys:
            items.append(k)
            items.append(key.value[k])
        return [result_cursor, items]

    @command((Key(Hash), bytes, bytes), (bytes, bytes))
    def hset(self, key: CommandItem, *args: bytes) -> int:
        return self._hset(key, *args)

    @command((Key(Hash), bytes, bytes))
    def hsetnx(self, key: CommandItem, field: bytes, value: bytes) -> int:
        if field in key.value:
            return 0
        return self._hset(key, field, value)

    @command((Key(Hash), bytes))
    def hstrlen(self, key: CommandItem, field: bytes) -> int:
        return len(key.value.get(field, b""))

    @command((Key(Hash),))
    def hvals(self, key: CommandItem) -> list[bytes]:
        return list(key.value.values())

    @command(name="HRANDFIELD", fixed=(Key(Hash),), repeat=(bytes,))
    def hrandfield(self, key: CommandItem, *args: bytes) -> list[list[str]] | list[str] | None:
        if len(args) > 2:
            raise SimpleError(msgs.SYNTAX_ERROR_MSG)
        if key.value is None or len(key.value) == 0:
            return None
        count = min(Int.decode(args[0]) if len(args) >= 1 else 1, len(key.value))
        withvalues = casematch(args[1], b"withvalues") if len(args) >= 2 else False
        if count == 0:
            return []

        if count < 0:  # Allow repetitions
            res = random.choices(sorted(key.value.items()), k=-count)
        else:  # Unique values from hash
            res = random.sample(sorted(key.value.items()), count)

        if withvalues:
            if self._resp_version == 2:
                res = [item for t in res for item in t]
            else:
                res = [list(t) for t in res]
        else:
            res = [t[0] for t in res]
        return res

    def _hexpire(self, key: CommandItem, when_ms: int, *args: bytes, command: str = "hexpire") -> list[int]:
        # Deal with input arguments
        (nx, xx, gt, lt), left_args = extract_args(
            args, ("nx", "xx", "gt", "lt"), left_from_first_unexpected=True, error_on_unexpected=False
        )
        if (nx, xx, gt, lt).count(True) > 1:
            raise SimpleError(msgs.NX_XX_GT_LT_ERROR_MSG)
        fields = _get_fields(left_args, command=command)
        hash_val: Hash = key.value
        if hash_val is None:
            return [-2] * len(fields)
        # process command
        res = []
        expired_fields: list[bytes] = []
        deleted_fields: list[bytes] = []
        for field in fields:
            if field not in hash_val:
                res.append(-2)
                continue
            current_expiration = hash_val.get_key_expireat(field)
            if (
                (nx and current_expiration is not None)
                or (xx and current_expiration is None)
                or (gt and (current_expiration is None or when_ms <= current_expiration))
                or (lt and current_expiration is not None and when_ms >= current_expiration)
            ):
                res.append(0)
                continue
            field_res = hash_val.set_key_expireat(field, when_ms)
            (expired_fields if field_res == 1 else deleted_fields).append(field)
            res.append(field_res)
        self.add_subkey_event(b"hexpire", key.key, expired_fields)
        self.add_subkey_event(b"hdel", key.key, deleted_fields)
        return res

    def _get_expireat(self, command: bytes, key: CommandItem, *args: bytes) -> list[int]:
        fields = _get_fields(args, command=command.decode().lower())
        hash_val: Hash = key.value
        if hash_val is None:
            return [-2] * len(fields)
        res = []
        for field in fields:
            if field not in hash_val:
                res.append(-2)
                continue
            when_ms = hash_val.get_key_expireat(field)
            if when_ms is None:
                res.append(-1)
            else:
                res.append(when_ms)
        return res

    @command(name="HEXPIRE", fixed=(Key(Hash), Int), repeat=(bytes,))
    def hexpire(self, key: CommandItem, seconds: int, *args: bytes) -> list[int]:
        if seconds < 0:
            raise SimpleError(msgs.HEXPIRE_INVALID_TIME_MSG)
        # Dragonfly caps a hash field's TTL at 2**26 seconds -- a tighter limit than the one it applies to whole keys --
        # and rejects anything past it while decoding.
        if self.server_type == "dragonfly" and seconds > DRAGONFLY_MAX_HASH_EXPIRE_SECONDS:
            raise SimpleError(msgs.INVALID_INT_MSG)
        when_ms = current_time() + seconds * 1000
        return self._hexpire(key, when_ms, *args, command="hexpire")

    @command(name="HPEXPIRE", fixed=(Key(Hash), Int), repeat=(bytes,))
    def hpexpire(self, key: CommandItem, milliseconds: int, *args: bytes) -> list[int]:
        if milliseconds < 0:
            raise SimpleError(msgs.HEXPIRE_INVALID_TIME_MSG)
        when_ms = current_time() + milliseconds
        return self._hexpire(key, when_ms, *args, command="hpexpire")

    @command(name="HEXPIREAT", fixed=(Key(Hash), Int), repeat=(bytes,))
    def hexpireat(self, key: CommandItem, unix_time_seconds: int, *args: bytes) -> list[int]:
        when_ms = unix_time_seconds * 1000
        return self._hexpire(key, when_ms, *args, command="hexpireat")

    @command(name="HPEXPIREAT", fixed=(Key(Hash), Int), repeat=(bytes,))
    def hpexpireat(self, key: CommandItem, unix_time_ms: int, *args: bytes) -> list[int]:
        return self._hexpire(key, unix_time_ms, *args, command="hpexpireat")

    @command(name="HPERSIST", fixed=(Key(Hash),), repeat=(bytes,))
    def hpersist(self, key: CommandItem, *args: bytes) -> list[int]:
        fields = _get_fields(args, command="hpersist")
        hash_val: Hash = key.value
        res = []
        persisted_fields = []
        for field in fields:
            if field not in hash_val:
                res.append(-2)
                continue
            if hash_val.clear_key_expireat(field):
                persisted_fields.append(field)
                res.append(1)
            else:
                res.append(-1)
        self.add_subkey_event(b"hpersist", key.key, persisted_fields)
        return res

    @command(
        name="HEXPIRETIME", fixed=(Key(Hash),), repeat=(bytes,), flags=msgs.FLAG_DO_NOT_CREATE, server_types=("redis",)
    )
    def hexpiretime(self, key: CommandItem, *args: bytes) -> list[int]:
        res = self._get_expireat(b"HEXPIRETIME", key, *args)
        return [(i // 1000 if i > 0 else i) for i in res]

    @command(name="HPEXPIRETIME", fixed=(Key(Hash),), repeat=(bytes,), server_types=("redis",))
    def hpexpiretime(self, key: CommandItem, *args: bytes) -> list[int]:
        res = self._get_expireat(b"HPEXPIRETIME", key, *args)
        return res

    @command(name="HTTL", fixed=(Key(Hash),), repeat=(bytes,), server_types=("redis",))
    def httl(self, key: CommandItem, *args: bytes) -> list[int]:
        curr_expireat_ms = self._get_expireat(b"HTTL", key, *args)
        curr_time_ms = current_time()
        return [((i - curr_time_ms) // 1000) if i > 0 else i for i in curr_expireat_ms]

    @command(name="HPTTL", fixed=(Key(Hash),), repeat=(bytes,), server_types=("redis",))
    def hpttl(self, key: CommandItem, *args: bytes) -> list[int]:
        curr_expireat_ms = self._get_expireat(b"HPTTL", key, *args)
        curr_time_ms = current_time()
        return [(i - curr_time_ms) if i > 0 else i for i in curr_expireat_ms]

    @command(name="HGETDEL", fixed=(Key(Hash),), repeat=(bytes,), server_types=("redis",))
    def hgetdel(self, key: CommandItem, *args: bytes) -> list[Any]:
        fields = _get_fields(args, command="hgetdel")
        hash_val: Hash = key.value
        res = [hash_val.pop(field) for field in fields]
        deleted_fields = [field for field, value in zip(fields, res) if value is not None]
        if deleted_fields:
            key.updated()
        self.add_subkey_event(b"hdel", key.key, deleted_fields)
        return res

    @command(name="HGETEX", fixed=(Key(Hash),), repeat=(bytes,), server_types=("redis",))
    def hgetex(self, key: CommandItem, *args: bytes) -> Any:
        (ex, px, exat, pxat, persist), left_args = extract_args(
            args,
            ("+ex", "+px", "+exat", "+pxat", "persist"),
            left_from_first_unexpected=True,
            error_on_unexpected=False,
        )
        if (ex is not None, px is not None, exat is not None, pxat is not None, persist).count(True) > 1:
            raise SimpleError("Only one of EX, PX, EXAT, PXAT or PERSIST arguments can be specified")
        fields = _get_fields(left_args, command="hgetex")
        hash_val: Hash = key.value

        when_ms = _get_when_ms(ex, px, exat, pxat)
        res = []
        persisted_fields: list[bytes] = []
        expired_fields: list[bytes] = []
        deleted_fields: list[bytes] = []
        for field in fields:
            res.append(hash_val.get(field))
            if field not in hash_val:
                continue
            if persist:
                if hash_val.clear_key_expireat(field):
                    persisted_fields.append(field)
            elif when_ms is not None:
                field_res = hash_val.set_key_expireat(field, when_ms)
                (expired_fields if field_res == 1 else deleted_fields).append(field)
        self.add_subkey_event(b"hexpire", key.key, expired_fields)
        self.add_subkey_event(b"hpersist", key.key, persisted_fields)
        self.add_subkey_event(b"hdel", key.key, deleted_fields)
        return res

    @command(name="HSETEX", fixed=(Key(Hash),), repeat=(bytes,), server_types=("redis",))
    def hsetex(self, key: CommandItem, *args: bytes) -> Any:
        (ex, px, exat, pxat, keepttl, fnx, fxx), left_args = extract_args(
            args,
            ("+ex", "+px", "+exat", "+pxat", "keepttl", "fnx", "fxx"),
            left_from_first_unexpected=True,
            error_on_unexpected=False,
        )
        if (ex is not None, px is not None, exat is not None, pxat is not None, keepttl).count(True) > 1:
            raise SimpleError("Only one of EX, PX, EXAT, PXAT or KEEPTTL arguments can be specified")
        if (fnx, fxx).count(True) > 1:
            raise SimpleError("Only one of FNX or FXX arguments can be specified")
        field_vals = _get_fields(left_args, with_values=True, command="hsetex")
        hash_val: Hash = key.value
        when_ms = _get_when_ms(ex, px, exat, pxat)

        field_keys = set(field_vals[::2])
        if fxx and len(field_keys - hash_val.getall().keys()) > 0:
            return 0
        if fnx and len(field_keys - hash_val.getall().keys()) < len(field_keys):
            return 0
        res = 0
        set_fields: list[bytes] = []
        expired_fields: list[bytes] = []
        deleted_fields: list[bytes] = []
        for i in range(0, len(field_vals), 2):
            field, value = field_vals[i], field_vals[i + 1]
            hash_val[field] = value
            res = 1
            set_fields.append(field)
            if not keepttl and when_ms is not None:
                field_res = hash_val.set_key_expireat(field, when_ms)
                (expired_fields if field_res == 1 else deleted_fields).append(field)
        key.updated()
        self.add_subkey_event(b"hset", key.key, set_fields)
        self.add_subkey_event(b"hexpire", key.key, expired_fields)
        self.add_subkey_event(b"hdel", key.key, deleted_fields)
        return res


def _get_fields(args: Sequence[bytes], with_values: bool = False, command: str = "") -> Sequence[bytes]:
    if len(args) < 3 or not casematch(args[0], b"fields"):
        raise SimpleError(msgs.WRONG_ARGS_MSG6.format(command))
    num_fields = Int.decode(args[1])
    if not with_values and num_fields != len(args) - 2:
        raise SimpleError(msgs.HEXPIRE_NUMFIELDS_DIFFERENT)
    if with_values and num_fields * 2 != len(args) - 2:
        raise SimpleError(msgs.HEXPIRE_NUMFIELDS_DIFFERENT)
    fields = args[2:]
    return fields


def _get_when_ms(ex: int | None, px: int | None, exat: int | None, pxat: int | None) -> int | None:
    if any(value is not None and value < 0 for value in (ex, px, exat, pxat)):
        raise SimpleError(msgs.HEXPIRE_INVALID_TIME_MSG)
    if ex is not None:
        when_ms = current_time() + ex * 1000
    elif px is not None:
        when_ms = current_time() + px
    elif exat is not None:
        when_ms = exat * 1000
    elif pxat is not None:
        when_ms = pxat
    else:
        when_ms = None
    return when_ms
