from __future__ import annotations

import functools
import itertools
import math
import random
import sys
from collections.abc import Sequence
from typing import Any, Callable, TypeVar

from fakeredis import _msgs as msgs
from fakeredis._command_args_parsing import extract_args, parse_mpop_args
from fakeredis._commands import (
    AfterAny,
    BeforeAny,
    CommandItem,
    Float,
    Int,
    Key,
    RedisType,
    StringTest,
    Timeout,
    command,
    fix_range,
)
from fakeredis._helpers import SimpleError, casematch, null_terminate
from fakeredis.commands_mixins._mixin_base import CommandsMixinBase
from fakeredis.model import ExpiringMembersSet, ZSet

SORTED_SET_METHODS = {
    "ZUNIONSTORE": lambda s1, s2: s1 | s2,
    "ZUNION": lambda s1, s2: s1 | s2,
    "ZINTERSTORE": lambda s1, s2: s1.intersection(s2),
    "ZINTER": lambda s1, s2: s1.intersection(s2),
    "ZDIFFSTORE": lambda s1, s2: s1 - s2,
    "ZDIFF": lambda s1, s2: s1 - s2,
}

_T = TypeVar("_T")


class ScoreTest(RedisType):
    """Argument converter for sorted set score endpoints."""

    def __init__(self, value: float, exclusive: bool = False, bytes_val: bytes | None = None):
        self.value = value
        self.exclusive = exclusive
        self.bytes_val = bytes_val

    @classmethod
    def decode(cls, value: bytes) -> ScoreTest:
        try:
            original_value = value
            exclusive = False
            if value[:1] == b"(":
                exclusive = True
                value = value[1:]
            fvalue = Float.decode(
                value,
                allow_leading_whitespace=True,
                allow_erange=True,
                allow_empty=True,
                crop_null=True,
            )
            return cls(fvalue, exclusive, original_value)
        except SimpleError:
            raise SimpleError(msgs.INVALID_MIN_MAX_FLOAT_MSG)

    def __str__(self) -> str:
        if self.exclusive:
            return f"({self.value!r}"
        else:
            return repr(self.value)

    @property
    def lower_bound(self) -> tuple[float, AfterAny | BeforeAny]:
        return self.value, AfterAny() if self.exclusive else BeforeAny()

    @property
    def upper_bound(self) -> tuple[float, AfterAny | BeforeAny]:
        return self.value, BeforeAny() if self.exclusive else AfterAny()


class SortedSetCommandsMixin(CommandsMixinBase):
    _scan: Callable[..., Any]
    _encodefloat: Callable[[float, bool], bytes]

    def _zpop(self, key: CommandItem, count: int, reverse: bool, flatten_list: bool) -> list[list[Any]]:
        if count < 0:
            raise SimpleError(msgs.INDEX_NEGATIVE_ERROR_MSG)
        zset = key.value
        members = list(zset)
        if reverse:
            members.reverse()
        members = members[:count]
        res = [[bytes(member), zset.get(member)] for member in members]
        if flatten_list:
            res = list(itertools.chain.from_iterable(res))
        for item in members:
            zset.discard(item)
        if members:
            # Mark dirty so the key is written back and removed once the set is empty (real Redis deletes a sorted set
            # when its last member is popped).
            key.updated()
        return res

    def _bzpop(self, keys: list[bytes], reverse: bool, first_pass: bool) -> list[bytes | list[bytes]] | None:
        for key in keys:
            item = CommandItem(key, self._db, item=self._db.get(key), default=[])
            temp_res = self._zpop(item, 1, reverse, flatten_list=False)
            if temp_res:
                item.writeback()  # remove the key if the set is now empty
                return [key, temp_res[0][0], temp_res[0][1]]
        return None

    def _zpop_flatten(self, count: int | None) -> bool:
        # RESP2 always returns a flat list. RESP3 returns a flat member/score pair only when no count was given; with an
        # explicit count it returns an array of pairs. Dragonfly answers RESP3 with an array of pairs either way.
        if self.server_type == "dragonfly":
            return self._resp_version == 2
        return self._resp_version == 2 or count is None

    @command((Key(ZSet),), (Int,))
    def zpopmin(self, key: CommandItem, count: int | None = None) -> list[Any]:
        return self._zpop(key, 1 if count is None else count, reverse=False, flatten_list=self._zpop_flatten(count))

    @command((Key(ZSet),), (Int,))
    def zpopmax(self, key: CommandItem, count: int | None = None) -> list[Any]:
        return self._zpop(key, 1 if count is None else count, reverse=True, flatten_list=self._zpop_flatten(count))

    @command((bytes, bytes), (bytes,), flags=msgs.FLAG_NO_SCRIPT)
    def bzpopmin(self, *args: bytes) -> list[list[bytes]] | None:
        keys = args[:-1]
        timeout = Timeout.decode(args[-1])
        res = self._blocking(timeout, functools.partial(self._bzpop, keys, False), self._empty_blocking_reply)  # type:ignore
        return res  # type:ignore

    @command((bytes, bytes), (bytes,), flags=msgs.FLAG_NO_SCRIPT)
    def bzpopmax(self, *args: bytes) -> list[list[bytes]] | None:
        keys = args[:-1]
        timeout = Timeout.decode(args[-1])
        res = self._blocking(timeout, functools.partial(self._bzpop, keys, True), self._empty_blocking_reply)  # type:ignore
        return res  # type:ignore

    @staticmethod
    def _limit_items(items: list[_T], offset: int, count: int) -> list[_T]:
        out: list[_T] = []
        for item in items:
            if offset:  # Note: not offset > 0, to match redis
                offset -= 1
                continue
            if count == 0:
                break
            count -= 1
            out.append(item)
        return out

    def _apply_withscores(self, items: list[tuple[bytes, bytes]], withscores: bool) -> list[Any]:
        if withscores:
            if self._resp_version == 2:
                out = []
                for item in items:
                    out.append(item[1])
                    out.append(item[0])
                return out
            return [[item[1], item[0]] for item in items]
        else:
            return [item[1] for item in items]

    @command((Key(ZSet), bytes, bytes), (bytes,))
    def zadd(self, key: CommandItem, *args: bytes) -> int | float | None:
        zset = key.value

        (nx, xx, ch, incr, gt, lt), left_args = extract_args(
            args,
            ("nx", "xx", "ch", "incr", "gt", "lt"),
            error_on_unexpected=False,
        )

        elements = left_args
        if not elements or len(elements) % 2 != 0:
            raise SimpleError(msgs.SYNTAX_ERROR_MSG)
        if nx and xx:
            raise SimpleError(msgs.ZADD_NX_XX_ERROR_MSG)
        if [nx, gt, lt].count(True) > 1:
            raise SimpleError(msgs.ZADD_NX_GT_LT_ERROR_MSG)
        if incr and len(elements) != 2:
            raise SimpleError(msgs.ZADD_INCR_LEN_ERROR_MSG)
        # Parse all scores first, before updating
        items = [
            (
                (
                    0.0 + Float.decode(elements[j]) if self.version >= (7,) else Float.decode(elements[j]),
                    elements[j + 1],
                )
            )
            for j in range(0, len(elements), 2)
        ]
        old_len = len(zset)
        changed_items: int = 0

        if incr:
            item_score, item_name = items[0]
            if (nx and item_name in zset) or (xx and item_name not in zset):
                return None
            if (gt or lt) and item_name in zset:
                current_score = zset.get(item_name)
                new_score = current_score + item_score
                if (gt and new_score <= current_score) or (lt and new_score >= current_score):
                    return None
            return self.zincrby(key, item_score, item_name)  # type: ignore[no-any-return]
        count = [nx, gt, lt, xx].count(True)
        for item_score, item_name in items:
            update = count == 0
            update = update or (count == 1 and nx and item_name not in zset)
            update = update or (count == 1 and xx and item_name in zset)
            update = update or (
                gt and ((item_name in zset and zset.get(item_name) < item_score) or (not xx and item_name not in zset))
            )
            update = update or (
                lt and ((item_name in zset and zset.get(item_name) > item_score) or (not xx and item_name not in zset))
            )

            if update and zset.add(item_name, item_score):
                changed_items += 1

        if changed_items:
            key.updated()

        if ch:
            return changed_items
        return len(zset) - old_len

    @command((Key(ZSet),))
    def zcard(self, key: CommandItem) -> int:
        return len(key.value)

    @command((Key(ZSet), ScoreTest, ScoreTest))
    def zcount(self, key: CommandItem, _min: ScoreTest, _max: ScoreTest) -> int:
        return key.value.zcount(_min.lower_bound, _max.upper_bound)  # type: ignore[no-any-return]

    @command((Key(ZSet), Float, bytes))
    def zincrby(self, key: CommandItem, increment: float, member: bytes) -> float:
        # Can't just default the old score to 0.0, because in IEEE754, adding 0.0 to something isn't a nop (e.g., 0.0 +
        # -0.0 == 0.0).
        score: float
        try:
            score = key.value.get(member, None) + increment
        except TypeError:
            score = increment
        if math.isnan(score):
            raise SimpleError(msgs.SCORE_NAN_MSG)
        key.value[member] = score
        key.updated()
        return score

    @command((Key(ZSet), StringTest, StringTest))
    def zlexcount(self, key: CommandItem, _min: StringTest, _max: StringTest) -> int:
        return key.value.zlexcount(_min.value, _min.exclusive, _max.value, _max.exclusive)  # type: ignore[no-any-return]

    def _zrangebyscore(
        self,
        key: CommandItem,
        _min: ScoreTest,
        _max: ScoreTest,
        reverse: bool,
        withscores: bool,
        offset: int,
        count: int,
    ) -> list[Any]:
        zset = key.value
        if reverse:
            _min, _max = _max, _min
        items = list(zset.irange_score(_min.lower_bound, _max.upper_bound, reverse=reverse))
        items = self._limit_items(items, offset, count)
        items = self._apply_withscores(items, withscores)
        return items

    def _zrange(
        self, key: CommandItem, start: ScoreTest, stop: ScoreTest, reverse: bool, withscores: bool, byscore: bool
    ) -> list[Any]:
        zset = key.value
        if byscore:
            items = zset.irange_score(start.lower_bound, stop.upper_bound, reverse=reverse)
        else:
            if start.bytes_val is None or stop.bytes_val is None:
                raise ValueError("start and stop must not be None")
            start_i, stop_i = Int.decode(start.bytes_val), Int.decode(stop.bytes_val)
            start_i, stop_i = fix_range(start_i, stop_i, len(zset))
            if reverse:
                start_i, stop_i = len(zset) - stop_i, len(zset) - start_i
            items = zset.islice_score(start_i, stop_i, reverse)
        items = self._apply_withscores(items, withscores)
        return items

    def _zrangebylex(
        self, key: CommandItem, _min: StringTest, _max: StringTest, reverse: bool, offset: int, count: int
    ) -> list[bytes]:
        zset = key.value
        if reverse:
            _min, _max = _max, _min
        items = zset.irange_lex(
            _min.value,
            _max.value,
            inclusive=(not _min.exclusive, not _max.exclusive),
            reverse=reverse,
        )
        items = self._limit_items(items, offset, count)
        return items

    def _zrange_args(self, key: CommandItem, start: bytes, stop: bytes, *args: bytes) -> list[Any]:
        (bylex, byscore, rev, (offset, count), withscores), _ = extract_args(
            args, ("bylex", "byscore", "rev", "++limit", "withscores")
        )
        if offset is not None and not bylex and not byscore:
            raise SimpleError(msgs.SYNTAX_ERROR_LIMIT_ONLY_WITH_MSG)
        if bylex and byscore:
            raise SimpleError(msgs.SYNTAX_ERROR_MSG)

        offset = offset or 0
        count = -1 if count is None else count

        if bylex:
            res = self._zrangebylex(key, StringTest.decode(start), StringTest.decode(stop), rev, offset, count)
        elif byscore:
            res = self._zrangebyscore(
                key, ScoreTest.decode(start), ScoreTest.decode(stop), rev, withscores, offset, count
            )
        else:
            res = self._zrange(key, ScoreTest.decode(start), ScoreTest.decode(stop), rev, withscores, byscore)
        return res

    @command((Key(ZSet), bytes, bytes), (bytes,))
    def zrange(self, key: CommandItem, start: bytes, stop: bytes, *args: bytes) -> list[Any]:
        return self._zrange_args(key, start, stop, *args)

    @command((Key(ZSet), Key(ZSet), bytes, bytes), (bytes,))
    def zrangestore(self, dest: CommandItem, src: CommandItem, start: bytes, stop: bytes, *args: bytes) -> int:
        results_list = self._zrange_args(src, start, stop, *args)
        res = ZSet()
        for item in results_list:
            res.add(item, src.value.get(item))
        dest.update(res)
        return len(res)

    @command((Key(ZSet), ScoreTest, ScoreTest), (bytes,))
    def zrevrange(self, key: CommandItem, start: ScoreTest, stop: ScoreTest, *args: bytes) -> list[Any]:
        (withscores, byscore), _ = extract_args(args, ("withscores", "byscore"))
        return self._zrange(key, start, stop, True, withscores, byscore)

    @command((Key(ZSet), StringTest, StringTest), (bytes,))
    def zrangebylex(self, key: CommandItem, _min: StringTest, _max: StringTest, *args: bytes) -> list[bytes]:
        ((offset, count),), _ = extract_args(args, ("++limit",))
        offset = offset or 0
        count = -1 if count is None else count
        return self._zrangebylex(key, _min, _max, False, offset, count)

    @command((Key(ZSet), StringTest, StringTest), (bytes,))
    def zrevrangebylex(self, key: CommandItem, _min: StringTest, _max: StringTest, *args: bytes) -> list[bytes]:
        ((offset, count),), _ = extract_args(args, ("++limit",))
        offset = offset or 0
        count = -1 if count is None else count
        return self._zrangebylex(key, _min, _max, True, offset, count)

    @command((Key(ZSet), ScoreTest, ScoreTest), (bytes,))
    def zrangebyscore(self, key: CommandItem, _min: ScoreTest, _max: ScoreTest, *args: bytes) -> list[Any]:
        (withscores, (offset, count)), _ = extract_args(args, ("withscores", "++limit"))
        offset = offset or 0
        count = -1 if count is None else count
        return self._zrangebyscore(key, _min, _max, False, withscores, offset, count)

    @command((Key(ZSet), ScoreTest, ScoreTest), (bytes,))
    def zrevrangebyscore(self, key: CommandItem, _min: ScoreTest, _max: ScoreTest, *args: bytes) -> list[Any]:
        (withscores, (offset, count)), _ = extract_args(args, ("withscores", "++limit"))
        offset = offset or 0
        count = -1 if count is None else count
        return self._zrangebyscore(key, _min, _max, True, withscores, offset, count)

    @command(name="ZRANK", fixed=(Key(ZSet), bytes), repeat=(bytes,))
    def zrank(self, key: CommandItem, member: bytes, *args: bytes) -> None | int | list[int | float]:
        (withscore,), _ = extract_args(args, ("withscore",))
        try:
            rank: int
            score: float
            rank, score = key.value.rank(member)
            if withscore:
                return [rank, score]
            return rank
        except KeyError:
            return None

    @command(name="ZREVRANK", fixed=(Key(ZSet), bytes), repeat=(bytes,))
    def zrevrank(self, key: CommandItem, member: bytes, *args: bytes) -> None | int | list[int | float]:
        (withscore,), _ = extract_args(args, ("withscore",))
        try:
            rank: int
            score: float
            rank, score = key.value.rank(member)
            rev_rank = len(key.value) - 1 - rank
            if withscore:
                return [rev_rank, score]
            return rev_rank
        except KeyError:
            return None

    @command((Key(ZSet), bytes), (bytes,))
    def zrem(self, key: CommandItem, *members: bytes) -> int:
        old_size = len(key.value)
        for member in members:
            key.value.discard(member)
        deleted = old_size - len(key.value)
        if deleted:
            key.updated()
        return deleted

    @command((Key(ZSet), StringTest, StringTest))
    def zremrangebylex(self, key: CommandItem, _min: StringTest, _max: StringTest) -> int:
        items = key.value.irange_lex(_min.value, _max.value, inclusive=(not _min.exclusive, not _max.exclusive))
        return self.zrem(key, *items)  # type: ignore[no-any-return]

    @command((Key(ZSet), ScoreTest, ScoreTest))
    def zremrangebyscore(self, key: CommandItem, _min: ScoreTest, _max: ScoreTest) -> int:
        items = key.value.irange_score(_min.lower_bound, _max.upper_bound, reverse=False)
        return self.zrem(key, *[item[1] for item in items])  # type: ignore[no-any-return]

    @command((Key(ZSet), Int, Int))
    def zremrangebyrank(self, key: CommandItem, start: int, stop: int) -> int:
        zset = key.value
        start, stop = fix_range(start, stop, len(zset))
        items = zset.islice_score(start, stop, reverse=False)
        return self.zrem(key, *[item[1] for item in items])  # type: ignore[no-any-return]

    @command((Key(ZSet), Int), (bytes, bytes))
    def zscan(self, key: CommandItem, cursor: int, *args: bytes) -> list[Any]:
        new_cursor, ans = self._scan(key.value.items(), cursor, *args)
        flat = []
        for member, score in ans:
            flat.append(member)
            flat.append(self._encodefloat(score, False))
        return [new_cursor, flat]

    @command((Key(ZSet), bytes))
    def zscore(self, key: CommandItem, member: bytes) -> float | None:
        try:
            score: float = key.value[member]
            return score
        except KeyError:
            return None

    @staticmethod
    def _get_zset(value: Any) -> ZSet:
        if isinstance(value, ExpiringMembersSet):
            zset = ZSet()
            for item in value:
                zset[item] = 1.0
            return zset
        elif isinstance(value, ZSet):
            return value
        else:
            raise SimpleError(msgs.WRONGTYPE_MSG)

    def _zset_scores_reply(self, zset: ZSet, withscores: bool, flat_on_dragonfly: bool = False) -> list[Any]:
        """Shape the reply of a ZDIFF/ZUNION/ZINTER, which RESP3 pairs up member and score.

        Dragonfly keeps the flat RESP2 shape for ZUNION and ZINTER, but not for ZDIFF.
        """
        if not withscores:
            return list(zset)
        if self._resp_version == 2 or (flat_on_dragonfly and self.server_type == "dragonfly"):
            return [item for member in zset for item in (member, zset[member])]
        return [[member, zset[member]] for member in zset]

    def _zunioninterdiff(self, func: str, dest: CommandItem | None, numkeys: int, *args: bytes) -> ZSet | int:
        if numkeys < 1:
            if self.server_type != "dragonfly":
                raise SimpleError(msgs.ZUNIONSTORE_KEYS_MSG.format(func.lower()))
            # Dragonfly reads numkeys as unsigned, so a negative one never decodes, and it words the zero case without
            # naming the command.
            raise SimpleError(msgs.INVALID_INT_MSG if numkeys < 0 else msgs.DRAGONFLY_AT_LEAST_ONE_KEY_MSG)
        if numkeys > len(args):
            raise SimpleError(msgs.SYNTAX_ERROR_MSG)
        aggregate = b"sum"
        weights = [1.0] * numkeys

        i = numkeys
        while i < len(args):
            arg = args[i]
            if casematch(arg, b"weights") and i + numkeys < len(args):
                weights = [Float.decode(x, decode_error=msgs.INVALID_WEIGHT_MSG) for x in args[i + 1 : i + numkeys + 1]]
                i += numkeys + 1
            elif casematch(arg, b"aggregate") and i + 1 < len(args):
                aggregate = null_terminate(args[i + 1]).lower()
                # The COUNT aggregator was added in redis 8.8
                count_supported = self.version >= (8, 8) and self.server_type == "redis"
                if aggregate not in (b"sum", b"min", b"max") and not (aggregate == b"count" and count_supported):
                    raise SimpleError(msgs.SYNTAX_ERROR_MSG)
                i += 2
            else:
                raise SimpleError(msgs.SYNTAX_ERROR_MSG)

        # Redis reads a plain set as a sorted set scoring every member 1. Dragonfly does that too, except in
        # ZDIFF/ZDIFFSTORE, which only accept sorted sets.
        zsets_only = self.server_type == "dragonfly" and func in {"ZDIFF", "ZDIFFSTORE"}
        sets = []
        for i in range(numkeys):
            item = CommandItem(args[i], self._db, item=self._db.get(args[i]), default=ZSet())
            if zsets_only and isinstance(item.value, ExpiringMembersSet):
                raise SimpleError(msgs.WRONGTYPE_MSG)
            sets.append(self._get_zset(item.value))

        out_members = set(sets[0])
        method = SORTED_SET_METHODS[func]
        for s in sets[1:]:
            out_members = method(out_members, set(s))  # type: ignore[no-untyped-call]

        # We first build a regular dict and turn it into a ZSet. The reason is subtle: a ZSet won't update a score from
        # -0 to +0 (or vice versa) through assignment, but a regular dict will.
        out: dict[bytes, Any] = {}
        # The sort affects the order of floating-point operations. Note that redis uses qsort(1), which has no stability
        # guarantees, so we can't be sure to match it in all cases.
        for s, w in sorted(zip(sets, weights), key=lambda x: len(x[0])):
            for member, score in s.items():
                # With COUNT, each set contributes its weight regardless of the member's score.
                score = w if aggregate == b"count" else score * w
                # Redis only does this step for ZUNIONSTORE. See https://github.com/antirez/redis/issues/3954.
                if func in {"ZUNIONSTORE", "ZUNION"} and math.isnan(score):
                    score = 0.0
                if member not in out_members:
                    continue
                if member in out:
                    old = out[member]
                    if aggregate in (b"sum", b"count"):
                        score += old
                        if math.isnan(score):
                            score = 0.0
                    elif aggregate == b"max":
                        score = max(old, score)
                    else:  # aggregate == b"min"
                        score = min(old, score)
                if math.isnan(score):
                    score = 0.0
                out[member] = score

        out_zset = ZSet()
        for member, score in out.items():
            out_zset[member] = score

        if dest is None:
            return out_zset

        dest.value = out_zset
        return len(out_zset)

    @command((Key(), Int, bytes), (bytes,))
    def zunionstore(self, dest: CommandItem, numkeys: int, *args: bytes) -> int:
        return self._zunioninterdiff("ZUNIONSTORE", dest, numkeys, *args)  # type: ignore[return-value]

    @command((Key(), Int, bytes), (bytes,))
    def zinterstore(self, dest: CommandItem, numkeys: int, *args: bytes) -> int:
        return self._zunioninterdiff("ZINTERSTORE", dest, numkeys, *args)  # type: ignore[return-value]

    @command((Key(), Int, bytes), (bytes,))
    def zdiffstore(self, dest: CommandItem, numkeys: int, *args: bytes) -> int:
        return self._zunioninterdiff("ZDIFFSTORE", dest, numkeys, *args)  # type: ignore[return-value]

    @command((Int, bytes), (bytes,))
    def zdiff(self, numkeys: int, *args: bytes) -> list[Any]:
        withscores = casematch(b"withscores", args[-1])
        sets = args[:-1] if withscores else args
        zset_res = self._zunioninterdiff("ZDIFF", None, numkeys, *sets)
        assert isinstance(zset_res, ZSet)
        return self._zset_scores_reply(zset_res, withscores)

    @command((Int, bytes), (bytes,))
    def zunion(self, numkeys: int, *args: bytes) -> list[Any]:
        withscores = casematch(b"withscores", args[-1])
        sets = args[:-1] if withscores else args
        zset_res = self._zunioninterdiff("ZUNION", None, numkeys, *sets)
        assert isinstance(zset_res, ZSet)
        return self._zset_scores_reply(zset_res, withscores, flat_on_dragonfly=True)

    @command((Int, bytes), (bytes,))
    def zinter(self, numkeys: int, *args: bytes) -> list[Any]:
        withscores = casematch(b"withscores", args[-1])
        sets = args[:-1] if withscores else args
        zset_res = self._zunioninterdiff("ZINTER", None, numkeys, *sets)
        assert isinstance(zset_res, ZSet)
        return self._zset_scores_reply(zset_res, withscores, flat_on_dragonfly=True)

    @command(name="ZINTERCARD", fixed=(Int, bytes), repeat=(bytes,))
    def zintercard(self, numkeys: int, *args: bytes) -> int:
        (limit,), left_args = extract_args(
            args,
            ("+limit",),
            error_on_unexpected=False,
            left_from_first_unexpected=False,
        )
        limit = limit if limit is not None else 0
        if limit < 0:
            # Dragonfly words the ZINTERCARD limit check differently from the SINTERCARD one.
            if self.server_type == "dragonfly":
                raise SimpleError(msgs.DRAGONFLY_LIMIT_NOT_POSITIVE_MSG)
            raise SimpleError(msgs.LIMIT_NEGATIVE_MSG)
        limit = limit if limit != 0 else sys.maxsize
        res = self._zunioninterdiff("ZINTER", None, numkeys, *left_args)
        return min(limit, len(res))  # type: ignore[arg-type]

    @command(name="ZMSCORE", fixed=(Key(ZSet), bytes), repeat=(bytes,))
    def zmscore(self, key: CommandItem, *members: str | bytes) -> list[float | None]:
        """Get the scores associated with the specified members in the sorted set stored at the key.

        For every member that does not exist in the sorted set, a nil value is returned.
        """
        scores = map(key.value.get, members)
        return list(scores)

    @command(name="ZRANDMEMBER", fixed=(Key(ZSet),), repeat=(bytes,))
    def zrandmember(self, key: CommandItem, *args: bytes) -> list[Any] | None:
        count, withscores = 1, None
        if len(args) > 0:
            count = Int.decode(args[0])
        if len(args) > 1:
            if casematch(b"withscores", args[1]):
                withscores = True
            else:
                raise SimpleError(msgs.SYNTAX_ERROR_MSG)
        zset = key.value
        if zset is None:
            return None if len(args) == 0 else []
        if count < 0:  # Allow repetitions
            res = random.choices(sorted(key.value.items()), k=-count)
        else:  # Unique values from hash
            count = min(count, len(key.value))
            res = random.sample(sorted(key.value.items()), count)

        if not withscores:
            res = [t[0] for t in res]
        elif self._resp_version == 2:
            res = [item for t in res for item in t]
        else:  # self._resp_version == 3 and withscores
            res = [list(item) for item in res]
        return res

    def _zmpop(self, keys: Sequence[bytes], count: int, reverse: bool, first_pass: bool) -> list[Any] | None:
        for key in keys:
            item = CommandItem(key, self._db, item=self._db.get(key), default=[])
            res = self._zpop(item, count, reverse, flatten_list=False)
            if res:
                item.writeback()  # remove the key if the set is now empty
                return [key, res]
            # Dragonfly allows COUNT 0, which names the first existing key but pops nothing.
            if count == 0 and item.value and self.server_type == "dragonfly":
                return [key, []]
        return None

    @command(fixed=(Int,), repeat=(bytes,))
    def zmpop(self, numkeys: int, *args: bytes) -> list[Any] | None:
        keys, count, reverse = parse_mpop_args("zmpop", numkeys, args, ("max", "min"), self.server_type)
        return self._zmpop(keys, count, reverse, False)

    @command(fixed=(Timeout, Int), repeat=(bytes,))
    def bzmpop(self, timeout: float, numkeys: int, *args: bytes) -> list[Any] | None:
        keys, count, reverse = parse_mpop_args("bzmpop", numkeys, args, ("max", "min"), self.server_type)
        return self._blocking(  # type: ignore[no-any-return]
            timeout,
            functools.partial(self._zmpop, keys, count, reverse),
        )
