from . import _typing
from ._connection import FakeConnection, FakeRedis, FakeRedisConnection, FakeStrictRedis
from ._server import FakeServer
from ._tcp_server import TcpFakeServer
from .aioredis import FakeAsyncRedisConnection
from .aioredis import FakeConnection as FakeAsyncConnection
from .aioredis import FakeRedis as FakeAsyncRedis

__version__ = _typing.lib_version
__author__ = "Daniel Moran"
__maintainer__ = "Daniel Moran"
__email__ = "daniel@moransoftware.ca"
__license__ = "BSD-3-Clause"
__url__ = "https://github.com/cunla/fakeredis-py"
__bugtrack_url__ = "https://github.com/cunla/fakeredis-py/issues"

__all__ = [
    "FakeAsyncConnection",
    "FakeAsyncRedis",
    "FakeAsyncRedisConnection",
    "FakeConnection",
    "FakeRedis",
    "FakeRedisConnection",
    "FakeServer",
    "FakeStrictRedis",
    "TcpFakeServer",
]

try:
    import valkey  # noqa: F401

    from ._valkey import FakeAsyncValkey, FakeStrictValkey, FakeValkey  # noqa: F401

    __all__.extend(
        [
            "FakeAsyncValkey",
            "FakeStrictValkey",
            "FakeValkey",
        ]
    )
except ImportError:
    pass
