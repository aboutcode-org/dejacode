"""Generators are callables that return a value used to populate a field.

If this callable has a `required` attribute (a list, mostly), for each
item in the list, if the item is a string, the field attribute with the
same name will be fetched from the field and used as argument for the
generator. If it is a callable (which will receive `field` as first
argument), it should return a list in the format (key, value) where key
is the argument name for generator and value is the value for that
argument.
"""

import string
import warnings
from collections.abc import Callable
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from os.path import abspath, dirname, join
from random import Random
from typing import Any
from uuid import UUID

from django.core.files.base import ContentFile
from django.db.backends.base.operations import BaseDatabaseOperations
from django.db.models import Field, Model
from django.utils.timezone import now

MAX_LENGTH = 300
# Using sys.maxint here breaks a bunch of tests when running against a
# Postgres database.
MAX_INT = 100000000000

baker_random = Random()  # noqa: S311


def get_content_file(content: bytes, name: str) -> ContentFile:
    return ContentFile(content, name=name)


def gen_file_field() -> ContentFile:
    name = "mock_file.txt"
    file_path = abspath(join(dirname(__file__), name))
    with open(file_path, "rb") as f:
        return get_content_file(f.read(), name=name)


def gen_image_field() -> ContentFile:
    name = "mock_img.jpeg"
    file_path = abspath(join(dirname(__file__), name))
    with open(file_path, "rb") as f:
        return get_content_file(f.read(), name=name)


def gen_from_list(a_list: list[str] | range) -> Callable:
    """Make sure all values of the field are generated from a list.

    Examples:
        Here how to use it.

        >>> from baker import Baker
        >>> class ExperienceBaker(Baker):
        >>>     attr_mapping = {'some_field': gen_from_list(['A', 'B', 'C'])}

    """
    return lambda: baker_random.choice(list(a_list))


# -- DEFAULT GENERATORS --


def gen_from_choices(
    choices: list, nullable: bool = True, blankable: bool = True
) -> Callable:
    choice_list = []
    for value, label in choices:
        if not nullable and value is None:
            continue
        if not blankable and value == "":
            continue

        if isinstance(label, (list, tuple)):
            for val, _lbl in label:
                choice_list.append(val)
        else:
            choice_list.append(value)

    return gen_from_list(choice_list)


def gen_integer(min_int: int = -MAX_INT, max_int: int = MAX_INT) -> int:
    # Only warn when using default bounds that could cause overflow
    if min_int == -MAX_INT or max_int == MAX_INT:
        warnings.warn(
            "gen_integer() may cause overflow errors with Django integer fields due to "
            "large default MAX_INT value. Consider using field-specific generators instead:\n"
            "- gen_positive_small_integer() for PositiveSmallIntegerField\n"
            "- gen_small_integer() for SmallIntegerField\n"
            "- gen_regular_integer() for IntegerField\n"
            "- gen_positive_integer() for PositiveIntegerField\n"
            "- gen_big_integer() for BigIntegerField\n"
            "- gen_positive_big_integer() for PositiveBigIntegerField\n"
            "See model_bakery.random_gen documentation for more details.",
            DeprecationWarning,
            stacklevel=2,
        )
    return baker_random.randint(min_int, max_int)


def _get_field_range(field_name: str) -> tuple[int, int]:
    """Get field range from Django's BaseDatabaseOperations."""
    return BaseDatabaseOperations.integer_field_ranges.get(
        field_name, (-MAX_INT, MAX_INT)
    )


def gen_small_integer(min_int: int | None = None, max_int: int | None = None) -> int:
    """Generate integer for SmallIntegerField.

    Defaults to Django's SmallIntegerField range (-32768 to 32767).
    Override with min_int/max_int to constrain range.
    """
    field_min, field_max = _get_field_range("SmallIntegerField")
    actual_min = min_int if min_int is not None else field_min
    actual_max = max_int if max_int is not None else field_max
    return baker_random.randint(actual_min, actual_max)


def gen_positive_small_integer(
    min_int: int | None = None, max_int: int | None = None
) -> int:
    """Generate integer for PositiveSmallIntegerField.

    Defaults to Django's PositiveSmallIntegerField range (0 to 32767).
    Override with min_int/max_int to constrain range.
    """
    field_min, field_max = _get_field_range("PositiveSmallIntegerField")
    actual_min = min_int if min_int is not None else field_min
    actual_max = max_int if max_int is not None else field_max
    return baker_random.randint(actual_min, actual_max)


def gen_positive_integer(min_int: int | None = None, max_int: int | None = None) -> int:
    """Generate integer for PositiveIntegerField.

    Defaults to Django's PositiveIntegerField range (0 to 2147483647).
    Override with min_int/max_int to constrain range.
    """
    field_min, field_max = _get_field_range("PositiveIntegerField")
    actual_min = min_int if min_int is not None else field_min
    actual_max = max_int if max_int is not None else field_max
    return baker_random.randint(actual_min, actual_max)


def gen_big_integer(min_int: int | None = None, max_int: int | None = None) -> int:
    """Generate integer for BigIntegerField.

    Defaults to Django's BigIntegerField range (-9223372036854775808 to 9223372036854775807).
    Override with min_int/max_int to constrain range.
    """
    field_min, field_max = _get_field_range("BigIntegerField")
    actual_min = min_int if min_int is not None else field_min
    actual_max = max_int if max_int is not None else field_max
    return baker_random.randint(actual_min, actual_max)


def gen_positive_big_integer(
    min_int: int | None = None, max_int: int | None = None
) -> int:
    """Generate integer for PositiveBigIntegerField.

    Defaults to Django's PositiveBigIntegerField range (0 to 9223372036854775807).
    Override with min_int/max_int to constrain range.
    """
    field_min, field_max = _get_field_range("PositiveBigIntegerField")
    actual_min = min_int if min_int is not None else field_min
    actual_max = max_int if max_int is not None else field_max
    return baker_random.randint(actual_min, actual_max)


def gen_regular_integer(min_int: int | None = None, max_int: int | None = None) -> int:
    """Generate integer for IntegerField.

    Defaults to Django's IntegerField range (-2147483648 to 2147483647).
    Override with min_int/max_int to constrain range.
    """
    field_min, field_max = _get_field_range("IntegerField")
    actual_min = min_int if min_int is not None else field_min
    actual_max = max_int if max_int is not None else field_max
    return baker_random.randint(actual_min, actual_max)


def gen_auto_field(min_int: int | None = None, max_int: int | None = None) -> int:
    """Generate integer for AutoField.

    Auto fields are auto-incrementing primary keys that start from 1.
    Defaults to range (1 to 2147483647).
    Override with min_int/max_int to constrain range.
    """
    field_min, field_max = _get_field_range("AutoField")
    # Auto fields start from 1, not 0 or negative
    actual_min = min_int if min_int is not None else max(field_min, 1)
    actual_max = max_int if max_int is not None else field_max
    return baker_random.randint(actual_min, actual_max)


def gen_big_auto_field(min_int: int | None = None, max_int: int | None = None) -> int:
    """Generate integer for BigAutoField.

    Auto fields are auto-incrementing primary keys that start from 1.
    Defaults to range (1 to 9223372036854775807).
    Override with min_int/max_int to constrain range.
    """
    field_min, field_max = _get_field_range("BigAutoField")
    # Auto fields start from 1, not 0 or negative
    actual_min = min_int if min_int is not None else max(field_min, 1)
    actual_max = max_int if max_int is not None else field_max
    return baker_random.randint(actual_min, actual_max)


def gen_small_auto_field(min_int: int | None = None, max_int: int | None = None) -> int:
    """Generate integer for SmallAutoField.

    Auto fields are auto-incrementing primary keys that start from 1.
    Defaults to range (1 to 32767).
    Override with min_int/max_int to constrain range.
    """
    field_min, field_max = _get_field_range("SmallAutoField")
    # Auto fields start from 1, not 0 or negative
    actual_min = min_int if min_int is not None else max(field_min, 1)
    actual_max = max_int if max_int is not None else field_max
    return baker_random.randint(actual_min, actual_max)


def gen_float(min_float: float = -1000000.0, max_float: float = 1000000.0) -> float:
    """
    Generate a random float uniformly distributed between `min_float` and `max_float`.

    Defaults to ±1,000,000.0 which is suitable for most test data scenarios.
    """
    return baker_random.uniform(min_float, max_float)


def gen_decimal(max_digits: int, decimal_places: int) -> Decimal:
    def num_as_str(x: int) -> str:
        return "".join([str(baker_random.randint(0, 9)) for _ in range(x)])

    if decimal_places:
        return Decimal(
            f"{num_as_str(max_digits - decimal_places - 1)}.{num_as_str(decimal_places)}"
        )

    return Decimal(num_as_str(max_digits))


gen_decimal.required = ["max_digits", "decimal_places"]  # type: ignore[attr-defined]


def gen_date() -> date:
    return now().date()


def gen_datetime() -> datetime:
    return now()


def gen_time() -> time:
    return now().time()


def gen_string(max_length: int) -> str:
    return "".join(baker_random.choice(string.ascii_letters) for _ in range(max_length))


def _gen_string_get_max_length(field: Field) -> tuple[str, int]:
    max_length = getattr(field, "max_length", None)
    if max_length is None:
        max_length = MAX_LENGTH
    return "max_length", max_length


gen_string.required = [_gen_string_get_max_length]  # type: ignore[attr-defined]


def gen_slug(max_length: int) -> str:
    valid_chars = string.ascii_letters + string.digits + "_-"
    return "".join(baker_random.choice(valid_chars) for _ in range(max_length))


gen_slug.required = ["max_length"]  # type: ignore[attr-defined]


def gen_text() -> str:
    warnings.warn(
        "\n"
        "Accessing `model_bakery.random_gen.gen_text` is deprecated "
        "and will be removed in a future major release. Please use "
        "`model_bakery.random_gen.gen_string` instead."
        "\n",
        DeprecationWarning,
        stacklevel=2,
    )
    return gen_string(MAX_LENGTH)


def gen_boolean() -> bool:
    return baker_random.choice((True, False))


def gen_null_boolean():
    return baker_random.choice((True, False, None))


def gen_url() -> str:
    return f"http://www.{gen_string(30)}.com/"


def gen_email() -> str:
    return f"{gen_string(10)}@example.com"


def gen_ipv6() -> str:
    return ":".join(format(baker_random.randint(1, 65535), "x") for _ in range(8))


def gen_ipv4() -> str:
    return ".".join(str(baker_random.randint(1, 255)) for _ in range(4))


def gen_ipv46() -> str:
    ip_gen = baker_random.choice([gen_ipv4, gen_ipv6])
    return ip_gen()


def gen_ip(protocol: str, default_validators: list[Callable]) -> str:
    from django.core.exceptions import ValidationError

    protocol = (protocol or "").lower()

    if not protocol:
        field_validator = default_validators[0]
        dummy_ipv4 = "1.1.1.1"
        dummy_ipv6 = "FE80::0202:B3FF:FE1E:8329"
        try:
            field_validator(dummy_ipv4)
            field_validator(dummy_ipv6)
            generator = gen_ipv46
        except ValidationError:
            try:
                field_validator(dummy_ipv4)
                generator = gen_ipv4
            except ValidationError:
                generator = gen_ipv6
    elif protocol == "ipv4":
        generator = gen_ipv4
    elif protocol == "ipv6":
        generator = gen_ipv6
    else:
        generator = gen_ipv46

    return generator()


gen_ip.required = ["protocol", "default_validators"]  # type: ignore[attr-defined]


def gen_byte_string(max_length: int = 16) -> bytes:
    generator = (baker_random.randint(0, 255) for x in range(max_length))
    return bytes(generator)


def gen_interval(
    interval_key: str = "milliseconds",
    min_interval: int = -365 * 24 * 60 * 60 * 1000,
    max_interval: int = 365 * 24 * 60 * 60 * 1000,
) -> timedelta:
    """
    Generate a random timedelta for `DurationField` or date range calculations.

    Defaults to ±1 year in milliseconds, suitable for most test scenarios.
    The `interval_key` determines which timedelta argument is set (e.g., 'seconds', 'days').
    """
    kwargs = {interval_key: baker_random.randint(min_interval, max_interval)}
    return timedelta(**kwargs)


def gen_content_type():
    from django.apps import apps
    from django.contrib.contenttypes.models import ContentType

    try:
        return ContentType.objects.get_for_model(baker_random.choice(apps.get_models()))
    except (AssertionError, RuntimeError):
        # AssertionError is raised by Django's test framework when db access is not available:
        # https://github.com/django/django/blob/stable/4.0.x/django/test/testcases.py#L150
        # RuntimeError is raised by pytest-django when db access is not available:
        # https://github.com/pytest-dev/pytest-django/blob/v4.5.2/pytest_django/plugin.py#L709
        warnings.warn(
            "Database access disabled, returning ContentType raw instance", stacklevel=1
        )
        return ContentType()


def gen_uuid() -> UUID:
    import uuid

    return uuid.uuid4()


def gen_array():
    return []


def gen_json():
    return {}


def gen_hstore():
    return {}


def _fk_model(field: Field) -> tuple[str, Model | None]:
    try:
        return ("model", field.related_model)
    except AttributeError:
        return ("model", field.related.parent_model)


def _prepare_related(
    model: str, _create_files=False, **attrs: Any
) -> Model | list[Model]:
    from .baker import prepare

    return prepare(model, **attrs)


def gen_related(model, _create_files=False, **attrs):
    from .baker import make

    return make(model, _create_files=_create_files, **attrs)


gen_related.required = [_fk_model, "_using"]  # type: ignore[attr-defined]
gen_related.prepare = _prepare_related  # type: ignore[attr-defined]


def gen_m2m(model, _create_files=False, **attrs):
    from .baker import MAX_MANY_QUANTITY, make

    return make(
        model, _create_files=_create_files, _quantity=MAX_MANY_QUANTITY, **attrs
    )


gen_m2m.required = [_fk_model, "_using"]  # type: ignore[attr-defined]


# GIS generators


def gen_coord() -> float:
    return baker_random.uniform(0, 1)


def gen_coords() -> str:
    return f"{gen_coord()} {gen_coord()}"


def gen_point() -> str:
    return f"POINT ({gen_coords()})"


def _gen_line_string_without_prefix() -> str:
    return f"({gen_coords()}, {gen_coords()})"


def gen_line_string() -> str:
    return f"LINESTRING {_gen_line_string_without_prefix()}"


def _gen_polygon_without_prefix() -> str:
    start = gen_coords()
    return f"(({start}, {gen_coords()}, {gen_coords()}, {start}))"


def gen_polygon() -> str:
    return f"POLYGON {_gen_polygon_without_prefix()}"


def gen_multi_point() -> str:
    return f"MULTIPOINT (({gen_coords()}))"


def gen_multi_line_string() -> str:
    return f"MULTILINESTRING ({_gen_line_string_without_prefix()})"


def gen_multi_polygon() -> str:
    return f"MULTIPOLYGON ({_gen_polygon_without_prefix()})"


def gen_geometry():
    return gen_point()


def gen_geometry_collection() -> str:
    return f"GEOMETRYCOLLECTION ({gen_point()})"


def gen_pg_numbers_range(number_cast: Callable[[int], Any]) -> Callable:
    """
    Factory that returns a generator for PostgreSQL numeric range fields.

    The returned generator creates ranges like [-N, N] where N is a random value
    between 1 and 100,000, cast to the appropriate numeric type (int, float, etc).
    """

    def gen_range():
        try:
            from psycopg.types.range import Range
        except ImportError:
            from psycopg2._range import NumericRange as Range

        base_num = baker_random.randint(1, 100000)
        return Range(number_cast(-1 * base_num), number_cast(base_num))

    return gen_range


def gen_date_range():
    """
    Generate random `DateRange` for PostgreSQL `DateRangeField`.

    The range spans a random date with a minimum interval of 1 day
    to avoid empty ranges in tests.
    """
    try:
        from psycopg.types.range import DateRange
    except ImportError:
        from psycopg2.extras import DateRange

    base_date = gen_date()
    interval = gen_interval(min_interval=24 * 60 * 60 * 1000)
    args = sorted([base_date - interval, base_date + interval])
    return DateRange(*args)


def gen_datetime_range():
    """
    Generate random `TimestamptzRange` for PostgreSQL DateTimeRangeField.

    The range spans a random datetime with a minimum interval of 1 day
    to avoid empty ranges in tests.
    """
    try:
        from psycopg.types.range import TimestamptzRange
    except ImportError:
        from psycopg2.extras import DateTimeTZRange as TimestamptzRange

    base_datetime = gen_datetime()
    interval = gen_interval(min_interval=24 * 60 * 60 * 1000)
    args = sorted([base_datetime - interval, base_datetime + interval])
    return TimestamptzRange(*args)
