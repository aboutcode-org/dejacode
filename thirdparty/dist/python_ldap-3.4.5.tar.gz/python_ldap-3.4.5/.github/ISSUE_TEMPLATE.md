If you found a bug in python-ldap, or would request a new feature,
this is the place to let us know.

Please describe the issue and your environment here.

---

Issue description:






Steps to reproduce: 



Operating system: 

Python version: 

python-ldap version: 
