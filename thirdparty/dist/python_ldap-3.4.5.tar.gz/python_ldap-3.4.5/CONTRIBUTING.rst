Thank you for your interest in python-ldap!

If you wish to help, detailed instructions are in `Doc/contributing.rst`_,
and in `online documentation`_.

.. _Doc/contributing.rst: Doc/contributing.rst
.. _online documentation: https://python-ldap.readthedocs.io/en/latest/contributing.html


Open-source veretans should find no surprises there.
