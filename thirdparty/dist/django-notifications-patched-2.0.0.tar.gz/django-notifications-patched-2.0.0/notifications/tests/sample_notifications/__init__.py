default_app_config = 'notifications.tests.sample_notifications.apps.SampleNotificationsConfig'
