from django.apps import AppConfig


class hCaptchaFieldConfig(AppConfig):
    name = 'hcaptcha_field'
    verbose_name = 'hCaptcha Field'
