"""doc8 - A docutils linter."""

from __future__ import annotations
from doc8.version import __version__
from doc8.main import doc8  # noqa


__all__ = ("__version__",)
