# Copyright (C) 2024 Anthony Harrison
# SPDX-License-Identifier: MIT

VERSION: str = "0.3.2"
