print("All formatted!")
