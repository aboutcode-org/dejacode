This is a markdown document with two fenced code blocks:

```py
print( "hello" )
def foo(): pass
```

```pyi
print( "hello" )
def foo(): pass
```
