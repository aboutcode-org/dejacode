Author: Selwin Ong

Contributors:

* Ulrich Petri (https://github.com/ulope)