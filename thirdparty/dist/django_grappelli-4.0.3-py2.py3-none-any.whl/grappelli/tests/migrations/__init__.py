# added migrations here, because otherwise tests are not running as expected
# since the grappelli tests models are migrated before auth.user which leads
# to an issue with travis.
