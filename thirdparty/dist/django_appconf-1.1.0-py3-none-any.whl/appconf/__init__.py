from .base import AppConf  # noqa

__version__ = "1.1.0"
