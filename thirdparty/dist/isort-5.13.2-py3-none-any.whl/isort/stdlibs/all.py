from . import py2, py3

stdlib = py2.stdlib | py3.stdlib
