class NoSuchJobError(Exception):
    pass


class NoSuchGroupError(Exception):
    pass


class DeserializationError(Exception):
    pass


class InvalidJobDependency(Exception):
    pass


class InvalidJobOperationError(Exception):
    pass


class InvalidJobOperation(Exception):
    pass


class DequeueTimeout(Exception):
    pass


class ShutDownImminentException(BaseException):
    # Inherit from BaseException as this is used specifically as a
    # 'shutdown' signal and should not be caught by except Exception.
    def __init__(self, msg, extra_info):
        self.extra_info = extra_info
        super().__init__(msg)


class TimeoutFormatError(Exception):
    pass


class AbandonedJobError(Exception):
    pass


class SchedulerNotFound(Exception):
    pass


class DuplicateSchedulerError(Exception):
    pass


class StopRequested(Exception):
    pass
