nonlocal x + 1
