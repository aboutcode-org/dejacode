x = *a and b
x = *yield x
x = *yield from x
x = *lambda x: x
x = x := 1
