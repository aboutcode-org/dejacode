del x, y.
z
del x, y[
z
