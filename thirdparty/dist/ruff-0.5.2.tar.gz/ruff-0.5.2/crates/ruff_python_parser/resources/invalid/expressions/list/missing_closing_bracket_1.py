# Missing closing bracket 1: No elements on the same line, the one on the next line
# is considered to be part of the list.

[

x + y