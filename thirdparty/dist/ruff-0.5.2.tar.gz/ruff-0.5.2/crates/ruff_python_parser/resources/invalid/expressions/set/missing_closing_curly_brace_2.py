# Missing closing curly brace 2: One element on the line, the other one on the next line
# will be considered to be part of the set.

{1,

x + y