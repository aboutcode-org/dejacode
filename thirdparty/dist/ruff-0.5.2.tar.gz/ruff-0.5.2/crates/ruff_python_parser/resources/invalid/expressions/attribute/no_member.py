# The `second` is a variable on another line and not part of the attribute expression.
first.
second

# No member access after the dot.
last.