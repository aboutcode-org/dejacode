# Without the `in`, this is considered to be a unary `not`
x not

1 + 2