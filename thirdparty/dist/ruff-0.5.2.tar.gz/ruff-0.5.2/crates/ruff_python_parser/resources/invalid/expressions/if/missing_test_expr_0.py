# Missing test expression, followed by a statement
x if

def foo():
    pass