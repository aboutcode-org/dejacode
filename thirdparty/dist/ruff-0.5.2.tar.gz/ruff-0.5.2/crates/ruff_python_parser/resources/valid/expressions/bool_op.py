a and b
a and b and c
a or b
a or b or c
a and b or c
a and b and c or d or e and f or g
a and not b or c
yield a and b or c
not a and b or c
