'Hello World'
"😎"
'Foo' 'Bar'
(
    'A'
    'B'
    'C'
)
'''Olá, Mundo!'''
"""ABCDE"""
(
    '''aB'''
    '''cD'''
)
b'hello world'
b'bytes' b'concatenated'

