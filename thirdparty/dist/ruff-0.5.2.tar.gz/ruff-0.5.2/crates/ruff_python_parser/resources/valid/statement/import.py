import a
import a.b.c
import a.b.c as d
import a, b, c
import foo.bar as a, a.b.c.d as abcd
