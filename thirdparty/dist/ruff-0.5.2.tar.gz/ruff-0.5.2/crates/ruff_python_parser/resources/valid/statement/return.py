return
return x
return *x
return *x | y
return *x, *y
return (x := 1)
return None
return x and y
return 1 < 2
return 1, 2,
return call()
return attr.value()
return await x
return lambda x: y
