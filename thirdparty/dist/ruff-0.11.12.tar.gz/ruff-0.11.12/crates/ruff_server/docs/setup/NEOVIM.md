## Neovim Setup Guide for `ruff server`

This document has been moved to <https://docs.astral.sh/ruff/editors/setup/#neovim>.
