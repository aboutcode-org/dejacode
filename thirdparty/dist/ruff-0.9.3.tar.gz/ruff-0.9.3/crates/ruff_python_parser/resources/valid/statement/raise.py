# raise
raise
raise a
raise (a, b)
raise 1 < 2
raise a and b
raise lambda x: y
raise await x
raise x if True else y

# raise ... from ...
raise x from a
raise x from (a, b)
raise x from 1 < 2
raise x from a and b
raise x from lambda x: y
raise x from await x
raise x from x if True else y
