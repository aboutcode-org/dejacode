# Other simple statements are contained in their own files.

continue
break

if x: ...
if True: pass
1; 2; pass
1; ...; a if b else c

if c: B; del A
else: C
if x: yield x;