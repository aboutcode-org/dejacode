while x:
    ...

while (x > 1) and y:
    pass
else:
    ...

while x and y:
    ...
    print('Hello World!')

else:
    print('Olá, Mundo!')
    ...

while a := b: ...
while (a := b) and c: ...
while lambda x: x: ...
while await x: ...

if True:
    while x:
        pass
    else:
        pass
else:
    pass
