return *
return yield x
return yield from x
return x := 1
return *x and y
