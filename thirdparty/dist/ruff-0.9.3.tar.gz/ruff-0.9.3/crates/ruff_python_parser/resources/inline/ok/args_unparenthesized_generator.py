sum(x for x in range(10))
