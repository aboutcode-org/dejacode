sum(x for x in range(10), 5)
total(1, 2, x for x in range(5), 6)
