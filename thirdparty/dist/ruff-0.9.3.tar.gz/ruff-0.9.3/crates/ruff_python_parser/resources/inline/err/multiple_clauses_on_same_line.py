if True: pass elif False: pass else: pass
if True: pass; elif False: pass; else: pass
for x in iter: break else: pass
for x in iter: break; else: pass
try: pass except exc: pass else: pass finally: pass
try: pass; except exc: pass; else: pass; finally: pass
