raise from exc
raise from None
