type X[**P] = int
type X[**P = int] = int
type X[T, **P] = int
type X[T, **P = int] = int
