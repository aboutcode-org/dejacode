nonlocal x
nonlocal x, y, z
