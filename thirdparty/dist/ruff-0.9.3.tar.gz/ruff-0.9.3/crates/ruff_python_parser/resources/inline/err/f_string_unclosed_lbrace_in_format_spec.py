f"hello {x:"
f"hello {x:.3f"
