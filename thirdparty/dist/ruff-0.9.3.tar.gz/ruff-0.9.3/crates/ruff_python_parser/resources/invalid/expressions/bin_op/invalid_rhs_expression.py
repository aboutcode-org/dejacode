x + lambda y: y

x - yield y