x >= *y
x not in *y

*x < y
*x is not y