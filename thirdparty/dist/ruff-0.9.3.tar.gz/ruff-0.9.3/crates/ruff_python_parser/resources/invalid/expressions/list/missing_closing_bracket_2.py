# Missing closing bracket 2: One element on the line, the other one on the next line
# will be considered to be part of the list.

[1,

x + y