call(a, b, # comment \

def bar():
    pass