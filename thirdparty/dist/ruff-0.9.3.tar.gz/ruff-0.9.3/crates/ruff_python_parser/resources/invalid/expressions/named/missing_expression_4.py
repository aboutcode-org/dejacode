# No expression on the right side of the assignment expression

(x := )

x + y