x not in lambda y: y

x == yield y