from debug_toolbar.panels.history.panel import HistoryPanel

__all__: list[str] = [HistoryPanel.panel_id]
