"""
An extensible user-registration application for Django.

"""

__version__ = "3.4"
