"""Egg-info mixin for workdir-based file finding and SCM metadata writing.

Overrides ``find_sources()`` so that when a workdir is available on the
Distribution (via ``VersionInferenceData``), the file list comes from
``workdir.list_tracked_files()`` instead of ``walk_revctrl()`` (which
dispatches to ``setuptools.file_finders`` entry points with no context).

Also writes ``scm_version.json`` and ``scm_file_list.json`` into the
egg-info directory after ``run()`` creates it, so that sdists carry
the metadata needed for fallback discovery when no VCS is present.
Wheels omit these files via the ``bdist_wheel`` egg2dist mixin.
"""

from __future__ import annotations

import logging
import os

from pathlib import Path
from typing import TYPE_CHECKING

from setuptools.command.egg_info import egg_info as _egg_info
from setuptools.command.egg_info import manifest_maker
from setuptools.command.sdist import sdist
from setuptools.command.sdist import walk_revctrl
from vcs_versioning._file_finders import scm_search_known_failed

from .build_py import get_version_inference_data

if TYPE_CHECKING:
    from vcs_versioning._backends._scm_workdir import ScmWorkdir
    from vcs_versioning._fallback_workdir import FallbackWorkdir

    from .build_py import VersionInferenceData

    # Typing-only base -- see ``ScmEggInfoMixin`` for why the mixin has no
    # runtime base class.
    _MixinBase = _egg_info
else:
    _MixinBase = object

log = logging.getLogger(__name__)


class _ScmManifestMaker(manifest_maker):
    """``manifest_maker`` that uses pre-computed tracked files instead of
    ``walk_revctrl()``.

    Set ``_tracked_files`` before calling ``run()``; when ``None`` the
    standard ``walk_revctrl()`` path is used as fallback.
    """

    _tracked_files: list[str] | None = None

    def add_defaults(self) -> None:
        sdist.add_defaults(self)
        self.filelist.append(self.template)
        self.filelist.append(self.manifest)

        if self._tracked_files is not None:
            self.filelist.extend(self._tracked_files)
        else:
            rcfiles = list(walk_revctrl())
            if rcfiles:
                self.filelist.extend(rcfiles)
            elif os.path.exists(self.manifest):
                self.read_manifest()

        if os.path.exists("setup.py"):
            self.filelist.append("setup.py")

        ei_cmd = self.get_finalized_command("egg_info")
        self.filelist.graft(ei_cmd.egg_info)  # type: ignore[attr-defined,no-untyped-call]


def _normalize_tracked_files(files: list[str]) -> list[str]:
    """Convert absolute paths to CWD-relative paths for portable metadata."""
    cwd = os.getcwd()
    return [os.path.relpath(f, cwd) if os.path.isabs(f) else f for f in files]


def _scm_search_failed(data: VersionInferenceData | None) -> bool:
    """Whether the SCM search ran and turned up no workdir.

    ``data is None`` means inference never ran (setuptools-scm is merely
    installed), so nothing is known and the finders must still probe.

    Otherwise reading ``data.workdir`` is what settles the question, and it
    runs discovery now if inference short-circuited past it -- asking is the
    only honest answer to "did the search fail", and this is the moment a
    file list is actually wanted.  ``None`` then means no checkout, and a
    :class:`FallbackWorkdir` means discovery landed on archival or PKG-INFO
    metadata, so the SCM search itself failed.
    """
    if data is None:
        return False

    workdir = data.workdir
    if workdir is None:
        return True

    from vcs_versioning._fallback_workdir import FallbackWorkdir

    return isinstance(workdir, FallbackWorkdir)


def _list_tracked(workdir: ScmWorkdir | FallbackWorkdir) -> list[str] | None:
    """Tracked files as CWD-relative paths, or ``None`` when unanswerable.

    Paths are converted because setuptools' filelist rejects absolute ones.
    """
    try:
        files = workdir.list_tracked_files(workdir.project_root)
    except NotImplementedError:
        log.debug("workdir does not support list_tracked_files, using walk_revctrl")
        return None
    return _normalize_tracked_files(files) if files else None


def _get_tracked_files(data: VersionInferenceData | None) -> list[str] | None:
    """Extract tracked files from a workdir, or ``None`` to fall back.

    The version workdir answers first.  When it cannot -- a project whose
    ``root`` is not the checkout root, where version inference finds no SCM
    at all -- the enclosing checkout answers instead, because the file list
    follows the checkout the project sits in rather than the root it
    declared for versioning (#1540).
    """
    if data is None:
        return None

    if data.workdir is not None:
        tracked = _list_tracked(data.workdir)
        if tracked is not None:
            return tracked

    return _list_tracked(data.file_workdir) if data.file_workdir is not None else None


class ScmEggInfoMixin(_MixinBase):
    """Mixin for the ``egg_info`` command.

    Like :class:`~._integration.build_py.ScmVersionFileMixin` this has no
    runtime base class, so wrapping a project's own ``egg_info`` never
    reorders that project's MRO (#1529).

    * ``find_sources()`` -- uses the workdir from ``VersionInferenceData``
      to supply tracked files to ``manifest_maker`` without going through
      the ``setuptools.file_finders`` entry-point chain.
    * ``run()`` -- after the egg-info directory is created, writes
      ``scm_version.json`` and ``scm_file_list.json`` so that sdists
      carry fallback metadata.
    """

    def find_sources(self) -> None:
        data = get_version_inference_data(self.distribution)
        tracked = _get_tracked_files(data)

        if tracked is not None:
            manifest_filename = os.path.join(self.egg_info, "SOURCES.txt")
            mm = _ScmManifestMaker(self.distribution)
            mm.ignore_egg_info_dir = self.ignore_egg_info_in_manifest  # type: ignore[attr-defined]
            mm.manifest = manifest_filename
            mm._tracked_files = tracked
            mm.run()
            self.filelist = mm.filelist
        elif _scm_search_failed(data):
            # inference ran and found no SCM workdir -- walk_revctrl() would
            # re-probe every backend for a repository we already know is not
            # there, which is how a slow ``hg`` on PATH broke unrelated
            # builds (#1212)
            with scm_search_known_failed():
                super().find_sources()
        else:
            super().find_sources()

    def run(self) -> None:
        # Write SCM metadata *before* super().run() so that find_sources()
        # → manifest_maker → graft(egg_info) picks up the JSON files.
        self.mkpath(self.egg_info)
        self._write_scm_metadata()
        super().run()

    def _write_scm_metadata(self) -> None:
        """Write ``scm_version.json`` and ``scm_file_list.json`` into egg-info.

        The two files answer different questions and are written
        independently.  ``scm_version.json`` records what the SCM said about
        the version, so a preformatted version -- a pretended one -- must not
        be written there and passed off as SCM truth.  ``scm_file_list.json``
        records which files the checkout tracks, which a pretended version
        says nothing about, so it is written whenever a workdir can list
        them (#1540).
        """
        data = get_version_inference_data(self.distribution)
        if data is None:
            return

        try:
            from vcs_versioning._scm_metadata import scm_version_data_from_scm_version
            from vcs_versioning._scm_metadata import write_scm_file_list
            from vcs_versioning._scm_metadata import write_scm_version_data

            egg_info_dir = Path(self.egg_info)

            scm_version = data.scm_version
            if scm_version is not None and not scm_version.preformatted:
                version_data = scm_version_data_from_scm_version(scm_version)
                write_scm_version_data(egg_info_dir, version_data)

            tracked = _get_tracked_files(data)
            if tracked:
                write_scm_file_list(egg_info_dir, tracked)

        except Exception:
            log.debug("failed to write SCM metadata to egg-info", exc_info=True)


class egg_info(ScmEggInfoMixin, _egg_info):
    """Default egg_info with SCM file finding and metadata writing."""
