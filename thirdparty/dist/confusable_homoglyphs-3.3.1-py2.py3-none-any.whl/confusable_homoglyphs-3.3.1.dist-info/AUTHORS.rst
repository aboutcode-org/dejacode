=======
Credits
=======

Original Author and Former Maintainer
-------------------------------------

* Victor Felder <victorfelder@gmail.com>

Current Maintainer
------------------

* Elena “of Valhalla” Grandi <valhalla@trueelena.org>

Contributors
------------

* Ryan P Kilby  <rpkilby@ncsu.edu>
