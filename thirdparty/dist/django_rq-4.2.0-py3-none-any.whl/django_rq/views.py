from typing import Any, cast

from django.contrib import admin, messages
from django.contrib.admin.views.decorators import staff_member_required
from django.http import Http404, HttpRequest, HttpResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_POST
from rq import requeue_job
from rq.exceptions import NoSuchJobError
from rq.job import Job
from rq.registry import (
    DeferredJobRegistry,
    FailedJobRegistry,
    FinishedJobRegistry,
    ScheduledJobRegistry,
    StartedJobRegistry,
)
from rq.worker import Worker
from rq.worker_registration import clean_worker_registry

from .queues import get_queue_by_index, get_scheduler_by_index
from .settings import get_queues_list, get_queues_map
from .utils import (
    DEFAULT_ITEMS_PER_PAGE,
    get_displayable_connection_kwargs,
    get_executions,
    get_jobs,
    get_scheduler_pid,
    paginate,
    stop_jobs,
)
from .utils import (
    requeue_job as _requeue_job,
)


def rq_viewname(request: HttpRequest, viewname: str) -> str:
    current_app = getattr(request, "current_app", None)
    if current_app:
        return f"{current_app}:django_rq_{viewname}"
    return f"django_rq:{viewname}"


def each_context(request: HttpRequest) -> dict[str, Any]:
    return {
        **admin.site.each_context(request),
    }


@never_cache
@staff_member_required
def jobs(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)

    num_jobs = queue.count
    page, page_range, offset = paginate(request, num_jobs)

    if num_jobs > 0:
        jobs = queue.get_jobs(offset, DEFAULT_ITEMS_PER_PAGE)
    else:
        jobs = []

    context_data = {
        **each_context(request),
        'queue': queue,
        'queue_index': queue_index,
        'jobs': jobs,
        'num_jobs': num_jobs,
        'page': page,
        'page_range': page_range,
        'job_status': 'Queued',
    }
    return render(request, 'django_rq/jobs.html', context_data)


@never_cache
@staff_member_required
def queue_details(request: HttpRequest, queue_index: int) -> HttpResponse:
    try:
        queue = get_queue_by_index(queue_index)
    except IndexError:
        raise Http404(f"Couldn't find queue with this ID: {queue_index}")

    connection = queue.connection
    queue_config = get_queues_list()[queue_index]['connection_config']

    oldest_job_id = connection.lindex(queue.key, 0)
    newest_job_id = connection.lindex(queue.key, -1)
    oldest_queued_job = queue.fetch_job(oldest_job_id.decode('utf-8')) if oldest_job_id else None
    newest_queued_job = queue.fetch_job(newest_job_id.decode('utf-8')) if newest_job_id else None

    context_data = {
        **each_context(request),
        'queue': queue,
        'queue_index': queue_index,
        'connection_kwargs': get_displayable_connection_kwargs(queue),
        'queue_config': queue_config,
        'num_jobs': queue.count,
        'num_workers': Worker.count(queue=queue),
        'num_started': len(StartedJobRegistry(queue.name, connection)),
        'num_finished': len(FinishedJobRegistry(queue.name, connection)),
        'num_failed': len(FailedJobRegistry(queue.name, connection)),
        'num_deferred': len(DeferredJobRegistry(queue.name, connection)),
        'num_scheduled': len(ScheduledJobRegistry(queue.name, connection)),
        'scheduler_pid': get_scheduler_pid(queue),
        'oldest_queued_job': oldest_queued_job,
        'newest_queued_job': newest_queued_job,
    }
    return render(request, 'django_rq/queue_detail.html', context_data)


@never_cache
@staff_member_required
def finished_jobs(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)

    registry = FinishedJobRegistry(queue.name, queue.connection)

    num_jobs = len(registry)
    page, page_range, offset = paginate(request, num_jobs)

    if request.GET.get('desc', '1') == '1':
        sort_direction = 'descending'
    else:
        sort_direction = 'ascending'

    jobs = []

    if num_jobs > 0:
        job_ids = registry.get_job_ids(offset, offset + DEFAULT_ITEMS_PER_PAGE - 1, desc=sort_direction == 'descending')
        jobs = get_jobs(queue, job_ids, registry)

    context_data = {
        **each_context(request),
        'queue': queue,
        'queue_index': queue_index,
        'jobs': jobs,
        'num_jobs': num_jobs,
        'page': page,
        'page_range': page_range,
        'sort_direction': sort_direction,
        'job_status': 'Finished',
    }
    return render(request, 'django_rq/finished_jobs.html', context_data)


@never_cache
@staff_member_required
def failed_jobs(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)

    registry = FailedJobRegistry(queue.name, queue.connection)

    num_jobs = len(registry)
    page, page_range, offset = paginate(request, num_jobs)

    if request.GET.get('desc', '1') == '1':
        sort_direction = 'descending'
    else:
        sort_direction = 'ascending'

    jobs = []

    if num_jobs > 0:
        job_ids = registry.get_job_ids(offset, offset + DEFAULT_ITEMS_PER_PAGE - 1, desc=sort_direction == 'descending')
        jobs = get_jobs(queue, job_ids, registry)

    context_data = {
        **each_context(request),
        'queue': queue,
        'queue_index': queue_index,
        'jobs': jobs,
        'num_jobs': num_jobs,
        'page': page,
        'page_range': page_range,
        'sort_direction': sort_direction,
        'job_status': 'Failed',
    }
    return render(request, 'django_rq/failed_jobs.html', context_data)


@never_cache
@staff_member_required
def scheduled_jobs(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)

    registry = ScheduledJobRegistry(queue.name, queue.connection)

    num_jobs = len(registry)
    page, page_range, offset = paginate(request, num_jobs)
    jobs = []

    if request.GET.get('desc', '1') == '1':
        sort_direction = 'descending'
    else:
        sort_direction = 'ascending'

    if num_jobs > 0:
        job_ids = registry.get_job_ids(offset, offset + DEFAULT_ITEMS_PER_PAGE - 1, desc=sort_direction == 'descending')
        jobs = get_jobs(queue, job_ids, registry)
        for job in jobs:
            job.scheduled_at = registry.get_scheduled_time(job)  # type: ignore[attr-defined]

    context_data = {
        **each_context(request),
        'queue': queue,
        'queue_index': queue_index,
        'jobs': jobs,
        'num_jobs': num_jobs,
        'page': page,
        'page_range': page_range,
        'sort_direction': sort_direction,
        'job_status': 'Scheduled',
    }
    return render(request, 'django_rq/scheduled_jobs.html', context_data)


@never_cache
@staff_member_required
def started_jobs(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)

    registry = StartedJobRegistry(queue.name, queue.connection)

    num_jobs = len(registry)
    page, page_range, offset = paginate(request, num_jobs)
    jobs = []
    executions = []

    if num_jobs > 0:
        try:
            composite_keys = registry.get_job_and_execution_ids(offset, offset + DEFAULT_ITEMS_PER_PAGE - 1)
        except AttributeError:
            composite_keys = [
                cast(tuple[str, str], key.split(':'))
                for key in registry.get_job_ids(offset, offset + DEFAULT_ITEMS_PER_PAGE - 1)
            ]

        jobs = get_jobs(queue, [i[0] for i in composite_keys], registry)
        executions = get_executions(queue, composite_keys)

    context_data = {
        **each_context(request),
        'queue': queue,
        'queue_index': queue_index,
        'jobs': jobs,
        'num_jobs': num_jobs,
        'page': page,
        'page_range': page_range,
        'job_status': 'Started',
        'executions': executions,
    }
    return render(request, 'django_rq/started_job_registry.html', context_data)


@never_cache
@staff_member_required
def workers(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)
    clean_worker_registry(queue)
    all_workers = Worker.all(queue.connection)
    workers = [worker for worker in all_workers if queue.name in worker.queue_names()]

    context_data = {
        **each_context(request),
        'queue': queue,
        'queue_index': queue_index,
        'workers': workers,
    }
    return render(request, 'django_rq/workers.html', context_data)


@never_cache
@staff_member_required
def worker_details(request: HttpRequest, queue_index: int, key: str) -> HttpResponse:
    queue = get_queue_by_index(queue_index)
    worker = Worker.find_by_key(key, connection=queue.connection)
    assert worker
    # Convert microseconds to milliseconds
    worker.total_working_time = worker.total_working_time / 1000

    queue_names = ', '.join(worker.queue_names())

    context_data = {
        **each_context(request),
        'queue': queue,
        'queue_index': queue_index,
        'worker': worker,
        'queue_names': queue_names,
        'job': worker.get_current_job(),
        'total_working_time': worker.total_working_time * 1000,
    }
    return render(request, 'django_rq/worker_details.html', context_data)


@never_cache
@staff_member_required
def deferred_jobs(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)

    registry = DeferredJobRegistry(queue.name, queue.connection)

    num_jobs = len(registry)
    page, page_range, offset = paginate(request, num_jobs)
    jobs = []

    if request.GET.get('desc', '1') == '1':
        sort_direction = 'descending'
    else:
        sort_direction = 'ascending'

    if num_jobs > 0:
        job_ids = registry.get_job_ids(offset, offset + DEFAULT_ITEMS_PER_PAGE - 1, desc=sort_direction == 'descending')
        for job_id in job_ids:
            try:
                jobs.append(Job.fetch(job_id, connection=queue.connection, serializer=queue.serializer))
            except NoSuchJobError:
                pass

    context_data = {
        **each_context(request),
        'queue': queue,
        'queue_index': queue_index,
        'jobs': jobs,
        'num_jobs': num_jobs,
        'page': page,
        'page_range': page_range,
        'job_status': 'Deferred',
        'sort_direction': sort_direction,
    }
    return render(request, 'django_rq/deferred_jobs.html', context_data)


@never_cache
@staff_member_required
def job_detail(request: HttpRequest, queue_index: int, job_id: str) -> HttpResponse:
    queue = get_queue_by_index(queue_index)

    try:
        job = Job.fetch(job_id, connection=queue.connection, serializer=queue.serializer)
    except NoSuchJobError:
        raise Http404(f"Couldn't find job with this ID: {job_id}")

    try:
        job.func_name
        data_is_valid = True
    except:
        data_is_valid = False

    # Backward compatibility support for RQ < 1.12.0
    rv = job.connection.hget(job.key, 'result')
    if rv is not None:
        # cache the result
        job.legacy_result = job.serializer.loads(rv)  # type: ignore[attr-defined]
    try:
        exc_info = job._exc_info
    except AttributeError:
        exc_info = None

    dependencies = []
    # if job._dependency_ids:
    # Fetch dependencies if they exist
    # dependencies = Job.fetch_many(
    #     job._dependency_ids, connection=queue.connection, serializer=queue.serializer
    # )
    for dependency_id in job._dependency_ids:
        try:
            dependency = Job.fetch(dependency_id, connection=queue.connection, serializer=queue.serializer)
        except NoSuchJobError:
            dependency = None
        dependencies.append((dependency_id, dependency))

    dependents = []
    for dependent_id in job.dependent_ids:
        try:
            dependent = Job.fetch(dependent_id, connection=queue.connection, serializer=queue.serializer)
        except NoSuchJobError:
            dependent = None
        dependents.append((dependent_id, dependent))

    context_data = {
        **each_context(request),
        'queue_index': queue_index,
        'job': job,
        'queue': queue,
        'data_is_valid': data_is_valid,
        'exc_info': exc_info,
        'dependencies': dependencies,
        'dependents': dependents,
    }
    return render(request, 'django_rq/job_detail.html', context_data)


@never_cache
@staff_member_required
def result_detail(request: HttpRequest, queue_index: int, job_id: str, result_id: str) -> HttpResponse:
    queue = get_queue_by_index(queue_index)

    try:
        job = Job.fetch(job_id, connection=queue.connection, serializer=queue.serializer)
    except NoSuchJobError:
        raise Http404(f"Couldn't find job with this ID: {job_id}")

    result = next((result for result in job.results() if result.id == result_id), None)
    if not result:
        raise Http404(f"Couldn't find result with this ID: {result_id}")

    context_data = {
        **each_context(request),
        'queue_index': queue_index,
        'job': job,
        'queue': queue,
        'result': result,
    }
    return render(request, 'django_rq/result_detail.html', context_data)


@never_cache
@staff_member_required
def delete_job(request: HttpRequest, queue_index: int, job_id: str) -> HttpResponse:
    queue = get_queue_by_index(queue_index)
    job = Job.fetch(job_id, connection=queue.connection, serializer=queue.serializer)

    if request.method == 'POST':
        # Remove job id from queue and delete the actual job
        queue.connection.lrem(queue.key, 0, job.id)
        job.delete()
        messages.info(request, f'You have successfully deleted {job.id}')
        return redirect(rq_viewname(request, "jobs"), queue_index)

    context_data = {
        **each_context(request),
        'queue_index': queue_index,
        'job': job,
        'queue': queue,
    }
    return render(request, 'django_rq/delete_job.html', context_data)


@never_cache
@staff_member_required
def requeue_job_view(request: HttpRequest, queue_index: int, job_id: str) -> HttpResponse:
    queue = get_queue_by_index(queue_index)
    job = Job.fetch(job_id, connection=queue.connection, serializer=queue.serializer)

    if request.method == 'POST':
        requeue_job(job_id, connection=queue.connection, serializer=queue.serializer)
        messages.info(request, f'You have successfully requeued {job.id}')
        return redirect(rq_viewname(request, "job_detail"), queue_index, job_id)

    context_data = {
        **each_context(request),
        'queue_index': queue_index,
        'job': job,
        'queue': queue,
    }
    return render(request, 'django_rq/delete_job.html', context_data)


@never_cache
@staff_member_required
def clear_queue(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)

    if request.method == 'POST':
        queue.empty()
        messages.info(request, f'You have successfully cleared the queue {queue.name}')
        return redirect(rq_viewname(request, "jobs"), queue_index)

    context_data = {
        **each_context(request),
        'queue_index': queue_index,
        'queue': queue,
    }
    return render(request, 'django_rq/clear_queue.html', context_data)


@never_cache
@staff_member_required
def requeue_all(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)
    registry = FailedJobRegistry(queue=queue)

    if request.method == 'POST':
        job_ids = registry.get_job_ids()
        count = 0
        # Confirmation received
        for job_id in job_ids:
            try:
                requeue_job(job_id, connection=queue.connection, serializer=queue.serializer)
                count += 1
            except NoSuchJobError:
                pass

        messages.info(request, 'You have successfully requeued %d jobs!' % count)
        return redirect(rq_viewname(request, "jobs"), queue_index)

    context_data = {
        **each_context(request),
        'queue_index': queue_index,
        'queue': queue,
        'total_jobs': len(registry),
    }

    return render(request, 'django_rq/requeue_all.html', context_data)


@never_cache
@staff_member_required
def delete_failed_jobs(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)
    registry = FailedJobRegistry(queue=queue)

    if request.method == 'POST':
        job_ids = registry.get_job_ids()
        jobs = Job.fetch_many(job_ids, connection=queue.connection)
        count = 0
        for job in jobs:
            if job:
                job.delete()
                count += 1

        messages.info(request, 'You have successfully deleted %d jobs!' % count)
        return redirect(rq_viewname(request, "home"))

    context_data = {
        **each_context(request),
        'queue_index': queue_index,
        'queue': queue,
        'total_jobs': len(registry),
    }

    return render(request, 'django_rq/clear_failed_queue.html', context_data)


@never_cache
@staff_member_required
def confirm_action(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)
    next_url = request.META.get('HTTP_REFERER') or reverse(rq_viewname(request, "jobs"), args=[queue_index])

    if request.method == 'POST' and request.POST.get('action', False):
        # confirm action
        if request.POST.get('_selected_action', False):
            job_ids = request.POST.getlist('_selected_action')
            actionable_job_ids: list[str] = []
            jobs: list[Any] = []
            for job_id in job_ids:
                try:
                    jobs.append(Job.fetch(job_id, connection=queue.connection, serializer=queue.serializer))
                    actionable_job_ids.append(job_id)
                except NoSuchJobError:
                    jobs.append({'id': job_id, 'missing': True})
            context_data = {
                **each_context(request),
                'queue_index': queue_index,
                'action': request.POST['action'],
                'job_ids': actionable_job_ids,
                'jobs': jobs,
                'queue': queue,
                'next_url': next_url,
            }
            return render(request, 'django_rq/confirm_action.html', context_data)

    return redirect(next_url)


@never_cache
@staff_member_required
def actions(request: HttpRequest, queue_index: int) -> HttpResponse:
    queue = get_queue_by_index(queue_index)
    next_url = request.POST.get('next_url') or reverse(rq_viewname(request, "jobs"), args=[queue_index])

    if request.method == 'POST' and request.POST.get('action', False):
        # do confirmed action
        if request.POST.get('job_ids', False):
            job_ids = request.POST.getlist('job_ids')

            if request.POST['action'] == 'delete':
                for job_id in job_ids:
                    job = Job.fetch(job_id, connection=queue.connection, serializer=queue.serializer)
                    # Remove job id from queue and delete the actual job
                    queue.connection.lrem(queue.key, 0, job.id)
                    job.delete()
                messages.info(request, f'You have successfully deleted {len(job_ids)} jobs!')
            elif request.POST['action'] == 'requeue':
                requeued = 0
                for job_id in job_ids:
                    try:
                        job = Job.fetch(job_id, connection=queue.connection, serializer=queue.serializer)
                    except NoSuchJobError:
                        continue
                    _requeue_job(queue, job)
                    requeued += 1
                messages.info(
                    request,
                    'You have successfully requeued %d job%s!' % (requeued, '' if requeued == 1 else 's'),
                )
            elif request.POST['action'] == 'stop':
                stopped, failed_to_stop = stop_jobs(queue, job_ids)
                if len(stopped) > 0:
                    messages.info(request, 'You have successfully stopped %d jobs!' % len(stopped))
                if len(failed_to_stop) > 0:
                    messages.error(request, '%d jobs failed to stop!' % len(failed_to_stop))

    return redirect(next_url)


@never_cache
@staff_member_required
def enqueue_job(request: HttpRequest, queue_index: int, job_id: str) -> HttpResponse:
    """Enqueue deferred jobs"""
    queue = get_queue_by_index(queue_index)
    job = Job.fetch(job_id, connection=queue.connection, serializer=queue.serializer)

    if request.method == 'POST':
        _requeue_job(queue, job)
        messages.info(request, f'You have successfully enqueued {job.id}')
        return redirect(rq_viewname(request, "job_detail"), queue_index, job_id)

    context_data = {
        **each_context(request),
        'queue_index': queue_index,
        'job': job,
        'queue': queue,
    }
    return render(request, 'django_rq/delete_job.html', context_data)


@never_cache
@staff_member_required
@require_POST
def stop_job(request: HttpRequest, queue_index: int, job_id: str) -> HttpResponse:
    """Stop started job"""
    queue = get_queue_by_index(queue_index)
    stopped, _ = stop_jobs(queue, job_id)
    if len(stopped) == 1:
        messages.info(request, f'You have successfully stopped {job_id}')
        return redirect(rq_viewname(request, "job_detail"), queue_index, job_id)
    else:
        messages.error(request, f'Failed to stop {job_id}')
        return redirect(rq_viewname(request, "job_detail"), queue_index, job_id)


@never_cache
@staff_member_required
def scheduler_jobs(request: HttpRequest, scheduler_index: int) -> HttpResponse:
    scheduler = get_scheduler_by_index(scheduler_index)

    num_jobs = scheduler.count()
    page, page_range, offset = paginate(request, num_jobs)
    jobs = []

    if num_jobs > 0:
        jobs_times = scheduler.get_jobs(with_times=True, offset=offset, length=DEFAULT_ITEMS_PER_PAGE)
        for job, time in jobs_times:
            job.next_run = time
            job.queue_index = get_queues_map().get(job.origin, 0)
            if 'cron_string' in job.meta:
                job.schedule = f"cron: '{job.meta['cron_string']}'"
            elif 'interval' in job.meta:
                job.schedule = f"interval: {job.meta['interval']}"
                if 'repeat' in job.meta:
                    job.schedule += f" repeat: {job.meta['repeat']}"
            else:
                job.schedule = 'unknown'
            jobs.append(job)

    context_data = {
        **each_context(request),
        'scheduler': scheduler,
        'jobs': jobs,
        'num_jobs': num_jobs,
        'page': page,
        'page_range': page_range,
    }
    return render(request, 'django_rq/scheduler.html', context_data)
