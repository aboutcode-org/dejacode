pub(crate) use implicit_namespace_package::*;

mod implicit_namespace_package;
