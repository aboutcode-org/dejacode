def test ():
    if True:
        print(<RANGE_START>1 + 2)

    else:
        print(3 + 4)<RANGE_END>

    print(" Do not format this")



def test_empty_lines ():
    if True:
        print(<RANGE_START>1 + 2)


    else:
        print(3 + 4)<RANGE_END>

    print(" Do not format this")
