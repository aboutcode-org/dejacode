def  test():
    pass  <RANGE_START>

<RANGE_END>

def  test_formatted(): pass
