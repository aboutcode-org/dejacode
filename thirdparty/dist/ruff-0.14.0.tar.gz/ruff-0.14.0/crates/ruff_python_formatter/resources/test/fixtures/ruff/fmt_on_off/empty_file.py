# fmt: off

    # this does not work because there are no statements

# fmt: on
