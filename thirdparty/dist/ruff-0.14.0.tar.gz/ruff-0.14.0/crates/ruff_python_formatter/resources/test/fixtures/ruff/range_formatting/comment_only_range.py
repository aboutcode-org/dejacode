def test  ():
    <RANGE_START># Some leading comment
    # that spans multiple lines
    <RANGE_END>
    print("Do not format this" )

