# Regression test for: https://github.com/astral-sh/ruff/issues/7624
if symbol is not None:
    request["market"] = market["id"]
      #             "remaining_volume": "0.0",
else:
    pass
