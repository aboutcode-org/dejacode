def func():
    pass
# fmt: off
x = 1
# fmt: on


# fmt: off
def func():
    pass
# fmt: on
x = 1


# fmt: off
def func():
    pass
# fmt: on
def func():
    pass


# fmt: off
def func():
    pass
# fmt: off
def func():
    pass


# fmt: on
def func():
    pass
# fmt: on
def func():
    pass
