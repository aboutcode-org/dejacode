
# Removes the line above

a = 10  # Keeps the line above

# Separated by one line from `a` and `b`

b = 20
# Adds two lines after `b`
class Test:
    def a(self):
        pass
        # trailing comment

# two lines before, one line after

c = 30

while a == 10:
    print(a)

    # trailing comment with one line before

# one line before this leading comment

d = 40

while b == 20:
    print(b)
    # no empty line before

e = 50  # one empty line before
