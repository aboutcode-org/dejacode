"""Two blank lines between module docstring and a function def."""
def function():
    pass
