def f():
    nonlocal x, y, z


def f():
    # leading comment
    nonlocal x, y, z # end-of-line comment
    # trailing comment


def f():
    nonlocal analyze_featuremap_layer, analyze_featuremapcompression_layer, analyze_latencies_post, analyze_motions_layer, analyze_size_model


def f():
    nonlocal analyze_featuremap_layer, analyze_featuremapcompression_layer, analyze_latencies_post, analyze_motions_layer, analyze_size_model  # end-of-line comment
