l = [1,2,3,4]

def foo():
    yield l

    b = yield l

    c = [
        (yield l) , (
        yield l

    )]

    with (
        # Some comment
        yield
    ):
        pass

    if (yield):
        # comment
        pass


    # some comment
    for e in l : yield e # some comment

    for e in l:


        # some comment

        yield e

        # trail comment

    for e in l:
        # comment
        yield (((((((e)))))))  # Too many parentheses
        # comment


    for ridiculouslylongelementnameeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee in l:
        yield ridiculouslylongelementnameeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee


    for x in l: #comment
        yield x + (2 * 4) # trailing comment

    while (

        yield l
    ):
        pass

    yield from (yield l)

    (
        yield
        #comment 1
        * # comment 2
        # comment 3
        test, # comment 4
        1
    )

    yield (
        "#   * Make sure each ForeignKey and OneToOneField has `on_delete` set "
        "to the desired behavior"
    )

    yield aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa + bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb + ccccccccccccccccccccccccccccccccccccccccccccccccccccccc

yield ("Cache key will cause errors if used with memcached: %r " "(longer than %s)" % (
    key,
    MEMCACHE_MAX_KEY_LENGTH,
)
       )

yield "Cache key will cause errors if used with memcached: %r " "(longer than %s)" % (
    key,
    MEMCACHE_MAX_KEY_LENGTH,
)


yield ("Unnecessary")


yield (
    "#   * Make sure each ForeignKey and OneToOneField has `on_delete` set "
    "to the desired behavior"
)
yield (
    "#   * Remove `managed = False` lines if you wish to allow "
    "Django to create, modify, and delete the table"
)
yield (
    "# Feel free to rename the models, but don't rename db_table values or "
    "field names."
)

yield "#   * Make sure each ForeignKey and OneToOneField has `on_delete` set "    "to the desired behavior"
yield "#   * Remove `managed = False` lines if you wish to allow " "Django to create, modify, and delete the table"
yield "# Feel free to rename the models, but don't rename db_table values or "    "field names."

# Regression test for: https://github.com/astral-sh/ruff/issues/7420
result = yield self.request(
    f"/applications/{int(application_id)}/guilds/{int(scope)}/commands/{int(command_id)}/permissions"
)

result = yield (self.request(
    f"/applications/{int(application_id)}/guilds/{int(scope)}/commands/{int(command_id)}/permissions"
))

result = yield

result = yield (1 + f(1, 2, 3,))

result = (yield (1 + f(1, 2, 3,)))

print((yield x))
