print("Before range start" )

<RANGE_START>
if a   + b :
    print("formatted"  )

print("still in range"  )
<RANGE_END>

print("After range end"  )
