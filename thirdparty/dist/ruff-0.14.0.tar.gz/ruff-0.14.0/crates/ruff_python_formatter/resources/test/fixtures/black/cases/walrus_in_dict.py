# This is testing an issue that is specific to the preview style
{
    "is_update": (up := commit.hash in update_hashes)
}
