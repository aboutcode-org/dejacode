"""
An extensible user-registration application for Django.

"""

# SPDX-License-Identifier: BSD-3-Clause
