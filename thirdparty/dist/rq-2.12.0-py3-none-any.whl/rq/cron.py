from __future__ import annotations

import importlib.util
import json
import logging
import os
import signal
import socket
import sys
import time
import uuid
from collections.abc import Callable, Sequence
from datetime import datetime, timedelta, timezone
from typing import Any

from croniter import croniter
from redis import Redis
from redis.client import Pipeline

from . import cron_job_registry, cron_scheduler_registry
from .defaults import (
    DEFAULT_CRON_JOB_HISTORY_LIMIT,
    DEFAULT_CRON_JOB_HISTORY_TTL,
    DEFAULT_CRON_SCHEDULER_TTL,
    DEFAULT_LOGGING_DATE_FORMAT,
    DEFAULT_LOGGING_FORMAT,
    DEFAULT_RESULT_TTL,
)
from .exceptions import SchedulerNotFound, StopRequested
from .job import Job
from .logutils import setup_loghandlers
from .queue import Queue
from .serializers import resolve_serializer
from .utils import (
    NOT_JSON_SERIALIZABLE,
    as_text,
    decode_redis_hash,
    normalize_config_path,
    now,
    safe_json_dumps,
    str_to_date,
    utcformat,
    utcparse,
    validate_absolute_path,
)
from .webhook import Webhook


def get_cron_job_history_key(name: str) -> str:
    """Redis key of the sorted set holding IDs of jobs spawned by the named cron job"""
    return f'rq:cron_job:{name}:jobs'


def get_cron_job_ids(name: str, connection: Redis, start: int = 0, end: int = -1) -> list[str]:
    """Return IDs of jobs spawned by the named cron job, newest first.

    `start` and `end` are zero-based inclusive indexes into the newest-first
    ordering, following `zrange` semantics (`end=-1` means the oldest entry).
    Ordering among jobs enqueued at the same timestamp is unspecified.
    """
    return [as_text(job_id) for job_id in connection.zrange(get_cron_job_history_key(name), start, end, desc=True)]


class CronJob:
    """Represents a function to be run on a time interval.

    `name` identifies the logical cron job and defaults to `func_name`;
    multiple cron jobs may share a name.
    """

    def __init__(
        self,
        queue_name: str,
        func: Callable | None = None,
        func_name: str | None = None,
        args: tuple | None = None,
        kwargs: dict | None = None,
        interval: int | None = None,
        cron: str | None = None,
        job_timeout: int | None = None,
        result_ttl: int = DEFAULT_RESULT_TTL,
        ttl: int | None = None,
        failure_ttl: int | None = None,
        meta: dict | None = None,
        webhooks: Sequence[Webhook] | None = None,
        name: str = '',
    ):
        if interval and cron:
            raise ValueError('Cannot specify both interval and cron parameters')
        if not interval and not cron:
            raise ValueError('Must specify either interval or cron parameter')

        if webhooks and (
            not isinstance(webhooks, Sequence) or not all(isinstance(webhook, Webhook) for webhook in webhooks)
        ):
            raise TypeError('webhooks must be a sequence of Webhook instances')

        if func:
            self.func: Callable | None = func
            self.func_name: str = f'{func.__module__}.{func.__name__}'
        elif func_name:
            self.func = None
            self.func_name = func_name
        else:
            raise ValueError('Either func or func_name must be provided')

        self.name: str = name or self.func_name
        self.args: tuple = args or ()
        self.kwargs: dict = kwargs or {}
        self.interval: int | None = interval
        self.cron: str | None = cron
        self.queue_name: str = queue_name
        self.next_enqueue_time: datetime | None = None
        self.latest_enqueue_time: datetime | None = None

        # For cron jobs, set initial next_enqueue_time during initialization
        if self.cron:
            cron_iter = croniter(self.cron, now())
            self.next_enqueue_time = cron_iter.get_next(datetime)
        self.job_options: dict[str, Any] = {
            'job_timeout': job_timeout,
            'result_ttl': result_ttl,
            'ttl': ttl,
            'failure_ttl': failure_ttl,
            'meta': meta,
            # Normalize to a list and drop an empty sequence so it isn't stored/serialized,
            # matching Job (which omits empty webhooks)
            'webhooks': list(webhooks) if webhooks else None,
        }
        # Filter out None values
        self.job_options = {k: v for k, v in self.job_options.items() if v is not None}

    @property
    def job_history_key(self) -> str:
        """Redis key of the sorted set holding IDs of jobs spawned by this cron job"""
        return get_cron_job_history_key(self.name)

    def enqueue(self, connection: Redis) -> Job:
        """Enqueue this job to its queue, record it in the job history and update the next run time"""
        if not self.func:
            raise ValueError('CronJob has no function to enqueue. It may have been created for monitoring purposes.')

        queue = Queue(self.queue_name, connection=connection)
        # Enqueue the job and record it in one round trip
        with connection.pipeline() as pipeline:
            job = queue.enqueue(self.func, *self.args, **self.kwargs, **self.job_options, pipeline=pipeline)
            assert job.enqueued_at is not None  # narrows datetime | None for mypy
            pipeline.zadd(self.job_history_key, {job.id: job.enqueued_at.timestamp()})
            pipeline.zremrangebyrank(self.job_history_key, 0, -(DEFAULT_CRON_JOB_HISTORY_LIMIT + 1))
            pipeline.expire(self.job_history_key, DEFAULT_CRON_JOB_HISTORY_TTL)
            cron_job_registry.add(self.name, pipeline, enqueue_timestamp=job.enqueued_at.timestamp())
            pipeline.execute()
        logging.getLogger(__name__).info(f'Enqueued job {self.func.__name__} to queue {self.queue_name}')

        return job

    def get_job_ids(self, connection: Redis, start: int = 0, end: int = -1) -> list[str]:
        """Return IDs of jobs spawned by this cron job, newest first.

        `start` and `end` are zero-based inclusive indexes into the newest-first
        ordering, following `zrange` semantics (`end=-1` means the oldest entry).
        Ordering among jobs enqueued at the same timestamp is unspecified.
        """
        return get_cron_job_ids(self.name, connection, start, end)

    def get_next_enqueue_time(self) -> datetime:
        """Calculate the next run time based on interval or cron expression"""
        if self.cron:
            # Use cron expression to calculate next run time
            cron_iter = croniter(self.cron, self.latest_enqueue_time or now())
            return cron_iter.get_next(datetime)
        elif self.interval and self.latest_enqueue_time:
            # Use interval-based calculation
            return self.latest_enqueue_time + timedelta(seconds=self.interval)

        return datetime.max  # Far future if neither interval nor cron set

    def should_run(self) -> bool:
        """Check if this job should run now"""
        # For interval jobs that have never run, run immediately
        # Jobs with cron string always have next_enqueue_time set during initialization
        if not self.latest_enqueue_time and not self.cron:
            return True

        # For all other cases, check if next_enqueue_time has arrived
        if self.next_enqueue_time:
            return now() >= self.next_enqueue_time

        return False

    def set_enqueue_time(self, time: datetime) -> None:
        """Set latest run time to a given time and update next run time"""
        self.latest_enqueue_time = time

        # Update next run time if interval or cron is set
        if self.interval is not None or self.cron is not None:
            self.next_enqueue_time = self.get_next_enqueue_time()

    def to_dict(self) -> dict[str, Any]:
        """Convert CronJob instance to a dictionary for monitoring purposes"""
        obj = {
            'func_name': self.func_name,
            'name': self.name,
            'queue_name': self.queue_name,
            'args': safe_json_dumps(self.args) if self.args else None,
            'kwargs': safe_json_dumps(self.kwargs) if self.kwargs else None,
            'interval': self.interval,
            'cron': self.cron,
            'latest_enqueue_time': utcformat(self.latest_enqueue_time) if self.latest_enqueue_time else None,
            'next_enqueue_time': utcformat(self.next_enqueue_time) if self.next_enqueue_time else None,
        }
        # Add job options, filtering out None values
        # meta uses safe_json_dumps and webhooks are serialized to JSON; others are kept as-is (integers)
        for k, v in self.job_options.items():
            if v is not None:
                if k == 'meta':
                    obj[k] = safe_json_dumps(v)
                elif k == 'webhooks':
                    obj[k] = json.dumps([webhook.to_dict() for webhook in v])
                else:
                    obj[k] = v
        return obj

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CronJob:
        """Create a CronJob instance from dictionary data for monitoring purposes.

        Note: The returned CronJob will not have a func attribute and cannot be executed,
        but contains all the metadata for monitoring.
        """
        # Restore args - handle JSON string (from to_dict) or keep as-is (None or placeholder)
        args = data.get('args')
        if args and args != NOT_JSON_SERIALIZABLE:
            args = tuple(json.loads(args))

        # Restore kwargs - handle JSON string (from to_dict) or keep as-is (None or placeholder)
        kwargs = data.get('kwargs')
        if kwargs and kwargs != NOT_JSON_SERIALIZABLE:
            kwargs = json.loads(kwargs)

        # Restore meta - handle JSON string (from to_dict) or keep as-is (None or placeholder)
        meta = data.get('meta')
        if meta and meta != NOT_JSON_SERIALIZABLE:
            meta = json.loads(meta)

        # Restore webhooks - parse the JSON string from to_dict, else skip (missing or unserializable
        # placeholder). Unlike meta, webhooks are validated in __init__, so the sentinel can't pass through.
        webhooks = data.get('webhooks')
        if webhooks and webhooks != NOT_JSON_SERIALIZABLE:
            webhooks = [Webhook.from_dict(webhook) for webhook in json.loads(webhooks)]
        else:
            webhooks = None

        job = cls(
            queue_name=data['queue_name'],
            func_name=data['func_name'],
            # Pre-existing serialized data has no name field; fall back to func_name via __init__
            name=data.get('name', ''),
            args=args,
            kwargs=kwargs,
            interval=data.get('interval'),
            cron=data.get('cron'),
            job_timeout=data.get('job_timeout'),
            result_ttl=data.get('result_ttl', DEFAULT_RESULT_TTL),
            ttl=data.get('ttl'),
            failure_ttl=data.get('failure_ttl'),
            meta=meta,
            webhooks=webhooks,
        )

        # Restore timing information if present
        if data.get('latest_enqueue_time'):
            job.latest_enqueue_time = utcparse(data['latest_enqueue_time'])

        if data.get('next_enqueue_time'):
            job.next_enqueue_time = utcparse(data['next_enqueue_time'])

        return job


class CronScheduler:
    """Simple interval-based job scheduler for RQ"""

    def __init__(
        self,
        connection: Redis,
        logging_level: str | int = logging.INFO,
        name: str = '',
    ):
        self.connection: Redis = connection
        self._cron_jobs: list[CronJob] = []
        self.hostname: str = socket.gethostname()
        self.pid: int = os.getpid()
        self.name: str = name or f'{self.hostname}:{self.pid}:{uuid.uuid4().hex[:6]}'
        self.config_file: str = ''
        self.created_at: datetime = now()
        self.serializer = resolve_serializer()

        self.log: logging.Logger = logging.getLogger(__name__)
        if not self.log.hasHandlers():
            setup_loghandlers(
                level=logging_level,
                name=__name__,
                log_format=DEFAULT_LOGGING_FORMAT,
                date_format=DEFAULT_LOGGING_DATE_FORMAT,
            )
            self.log.propagate = False

    def __eq__(self, other) -> bool:
        """Equality does not take the database/connection into account"""
        if not isinstance(other, self.__class__):
            return False
        return self.name == other.name

    def __hash__(self) -> int:
        """The hash does not take the database/connection into account"""
        return hash(self.name)

    def register(
        self,
        func: Callable,
        queue_name: str,
        args: tuple | None = None,
        kwargs: dict | None = None,
        interval: int | None = None,
        cron: str | None = None,
        job_timeout: int | None = None,
        result_ttl: int = DEFAULT_RESULT_TTL,
        ttl: int | None = None,
        failure_ttl: int | None = None,
        meta: dict | None = None,
        webhooks: Sequence[Webhook] | None = None,
        name: str = '',
    ) -> CronJob:
        """Register a function to be run at regular intervals"""
        cron_job = CronJob(
            queue_name=queue_name,
            func=func,
            args=args,
            kwargs=kwargs,
            interval=interval,
            cron=cron,
            job_timeout=job_timeout,
            result_ttl=result_ttl,
            ttl=ttl,
            failure_ttl=failure_ttl,
            meta=meta,
            webhooks=webhooks,
            name=name,
        )

        self._cron_jobs.append(cron_job)

        job_key = f'{func.__module__}.{func.__name__}'
        if interval:
            self.log.info(f"Registered '{job_key}' to run on {queue_name} every {interval} seconds")
        elif cron:
            self.log.info(f"Registered '{job_key}' to run on {queue_name} with cron schedule '{cron}'")

        return cron_job

    def get_jobs(self) -> list[CronJob]:
        """Get all registered cron jobs"""
        return self._cron_jobs

    def enqueue_jobs(self) -> list[CronJob]:
        """Enqueue all jobs that are due to run"""
        enqueue_time = now()
        enqueued_jobs: list[CronJob] = []
        for job in self._cron_jobs:
            if job.should_run():
                job.enqueue(self.connection)
                job.set_enqueue_time(enqueue_time)
                enqueued_jobs.append(job)
        return enqueued_jobs

    def calculate_sleep_interval(self) -> float:
        """Calculate how long to sleep until the next job is due.

        Returns the number of seconds to sleep, with a maximum of 60 seconds
        to ensure we check regularly.
        """
        current_time = now()

        # Find the next job to run
        next_job_times = [job.next_enqueue_time for job in self._cron_jobs if job.next_enqueue_time]

        if not next_job_times:
            return 60  # Default sleep time of 60 seconds

        # Find the closest job by next_enqueue_time
        closest_time = min(next_job_times)

        # Calculate seconds until next job
        seconds_until_next = (closest_time - current_time).total_seconds()

        # If negative or zero, the job is overdue, so run immediately
        if seconds_until_next <= 0:
            return 0

        # Cap maximum sleep time at 60 seconds
        return min(seconds_until_next, 60)

    def _install_signal_handlers(self):
        """Install signal handlers for graceful shutdown."""
        signal.signal(signal.SIGINT, self._request_stop)
        signal.signal(signal.SIGTERM, self._request_stop)

    def _request_stop(self, signum, frame):
        """Handle shutdown signals gracefully."""
        self.log.info('CronScheduler %s: received shutdown signal %s', self.name, signum)
        raise StopRequested()

    def start(self):
        """Start the cron scheduler"""
        self.log.info('CronScheduler %s: starting...', self.name)

        # Register birth and install signal handlers
        self._install_signal_handlers()
        self.register_birth()

        try:
            while True:
                enqueued_jobs = self.enqueue_jobs()
                if enqueued_jobs:
                    # Persist updated job timing data to Redis
                    self.save()
                self.heartbeat()
                sleep_time = self.calculate_sleep_interval()
                if sleep_time > 0:
                    self.log.debug(f'Sleeping for {sleep_time} seconds...')
                    time.sleep(sleep_time)
        except KeyboardInterrupt:
            self.log.info('CronScheduler %s: received KeyboardInterrupt', self.name)
        except StopRequested:
            self.log.info('CronScheduler %s: stop requested', self.name)
        finally:
            # Register death before shutting down
            self.register_death()
            self.log.info('CronScheduler %s: shutdown complete', self.name)

    def load_config_from_file(self, config_path: str):
        """
        Dynamically load a cron config file and register all jobs with this Cron instance.

        Supports both dotted import paths (e.g. 'app.cron_config') and file paths
        (e.g. '/path/to/app/cron_config.py', 'app/cron_config.py'). The .py
        extension is recommended for file paths for clarity.

        Jobs defined in the config file must use the global `rq.cron.register` function.

        Args:
            config_path: Path to the cron_config.py file or module path.
        """
        self.config_file = config_path
        self.log.info(f'Loading cron configuration from {config_path}')

        global _job_data_registry
        _job_data_registry = []  # Clear global registry before loading module

        if os.path.isabs(config_path):
            # Absolute paths must be loaded by file path (cannot be converted to valid module paths)
            self.log.debug(f'Loading absolute file path: {config_path}')

            # Validate the file path
            validate_absolute_path(config_path)

            # Load the file as a module
            module_name = f'rq_cron_config_{os.path.basename(config_path).replace(".", "_")}'
            try:
                spec = importlib.util.spec_from_file_location(module_name, config_path)
                if spec is None or spec.loader is None:
                    error_msg = f'Could not create module spec for {config_path}'
                    self.log.error(error_msg)
                    raise ImportError(error_msg)

                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)
                self.log.debug(f'Successfully loaded config from file: {config_path}')
            except Exception as e:
                if module_name in sys.modules:
                    del sys.modules[module_name]
                error_msg = f"Failed to load configuration file '{config_path}': {e}"
                self.log.error(error_msg)
                raise ImportError(error_msg) from e
        else:
            # Relative paths and dotted paths - normalize to dotted module format
            normalized_path = normalize_config_path(config_path)
            self.log.debug(f'Normalized path: {normalized_path}')

            # Import the module using the normalized dotted path
            try:
                if normalized_path in sys.modules:
                    importlib.reload(sys.modules[normalized_path])
                else:
                    importlib.import_module(normalized_path)
                self.log.debug(f'Successfully loaded config from module: {normalized_path}')
            except ImportError as e:
                error_msg = f"Failed to import configuration module '{normalized_path}' (from '{config_path}'): {e}"
                self.log.error(error_msg)
                raise ImportError(error_msg) from e
            except Exception as e:
                error_msg = f"An error occurred while importing '{normalized_path}' (from '{config_path}'): {e}"
                self.log.error(error_msg)
                raise Exception(error_msg) from e

        # Now that the module has been loaded (which populated _job_data_registry
        # via the global `register` function), register the jobs with *this* instance.
        job_count = 0

        for data in _job_data_registry:
            self.log.debug(f'Registering job from config: {data["func"].__name__}')
            try:
                self.register(**data)  # Calls the instance's register method
                job_count += 1
            except Exception as e:
                self.log.error(f'Failed to register job {data["func"].__name__} from config: {e}', exc_info=True)
                # Decide if loading should fail entirely or just skip the job
                # For now, log the error and continue

        # Clear the global registry after we're done
        _job_data_registry.clear()
        self.log.info(f"Successfully registered {job_count} cron jobs from '{config_path}'")
        # Method modifies the instance, no need to return self unless chaining is desired

    @property
    def key(self) -> str:
        """Redis key for this CronScheduler instance"""
        return f'rq:cron_scheduler:{self.name}'

    def to_dict(self) -> dict:
        """Convert CronScheduler instance to a dictionary for Redis storage"""
        obj = {
            'hostname': self.hostname,
            'pid': str(self.pid),
            'name': self.name,
            'created_at': utcformat(self.created_at),
            'config_file': self.config_file or '',
            'cron_jobs': json.dumps([job.to_dict() for job in self._cron_jobs]),
        }
        return obj

    def save(self, pipeline: Pipeline | None = None) -> None:
        """Save CronScheduler instance to Redis hash with TTL"""
        connection = pipeline if pipeline is not None else self.connection.pipeline()
        connection.hset(self.key, mapping=self.to_dict())
        connection.expire(self.key, DEFAULT_CRON_SCHEDULER_TTL)

        if pipeline is None:
            connection.execute()

    def restore(self, raw_data: dict) -> None:
        """Restore CronScheduler instance from Redis hash data."""
        obj = decode_redis_hash(raw_data, decode_values=True)

        self.hostname = obj.get('hostname', '')
        self.pid = int(obj.get('pid', 0))
        self.name = obj.get('name', self.name)
        created_at = obj.get('created_at')
        if created_at:
            self.created_at = str_to_date(created_at)
        self.config_file = obj.get('config_file', '')

        # Restore CronJob data if available
        if obj.get('cron_jobs'):
            try:
                jobs_data = json.loads(obj['cron_jobs'])
                self._cron_jobs = [CronJob.from_dict(job_data) for job_data in jobs_data]
            except (json.JSONDecodeError, KeyError, TypeError) as e:
                self.log.warning(f'Failed to restore cron jobs: {e}')
                self._cron_jobs = []
        else:
            # Backward compatibility: missing field = no jobs
            self._cron_jobs = []

    @classmethod
    def fetch(cls, name: str, connection: Redis) -> CronScheduler:
        """Fetch a CronScheduler instance from Redis by name."""
        key = f'rq:cron_scheduler:{name}'
        raw_data = connection.hgetall(key)

        if not raw_data:
            raise SchedulerNotFound(f"CronScheduler with name '{name}' not found")

        scheduler = cls(connection=connection, name=name)
        scheduler.restore(raw_data)
        return scheduler

    @classmethod
    def all(cls, connection: Redis, cleanup: bool = True) -> list[CronScheduler]:
        """Returns all CronScheduler instances from the registry

        Args:
            connection: Redis connection to use
            cleanup: If True, removes stale entries from registry before fetching schedulers

        Returns:
            List of CronScheduler instances
        """
        from contextlib import suppress

        if cleanup:
            cron_scheduler_registry.cleanup(connection)

        scheduler_names = cron_scheduler_registry.get_keys(connection)
        schedulers = []

        for name in scheduler_names:
            with suppress(SchedulerNotFound):
                scheduler = cls.fetch(name, connection)
                schedulers.append(scheduler)

        return schedulers

    def register_birth(self) -> None:
        """Register this scheduler's birth in the scheduler registry and save data to Redis hash"""
        self.log.info(f'CronScheduler {self.name}: registering birth...')

        with self.connection.pipeline() as pipeline:
            cron_scheduler_registry.register(self, pipeline)
            self.save(pipeline)
            pipeline.execute()

    def register_death(self, pipeline: Pipeline | None = None) -> None:
        """Register this scheduler's death by removing it from the scheduler registry"""
        self.log.info(f'CronScheduler {self.name}: registering death...')
        cron_scheduler_registry.unregister(self, pipeline)

    def heartbeat(self) -> None:
        """Update this scheduler's last seen timestamp in the registry and refresh
        its Redis hash TTL, re-creating both if they have expired or been pruned.
        """
        with self.connection.pipeline() as pipeline:
            pipeline.zadd(cron_scheduler_registry.get_registry_key(), {self.name: time.time()})
            pipeline.expire(self.key, DEFAULT_CRON_SCHEDULER_TTL)
            zadd_result, expire_result = pipeline.execute()

        if not expire_result:
            # expire returns 0 when the key is missing: the hash expired
            # (e.g. the host slept past the TTL), so re-create it
            self.save()

        # zadd returns 1 if the member was newly added
        if zadd_result:
            self.log.info('CronScheduler %s: re-registered in scheduler registry', self.name)
        else:
            self.log.debug('CronScheduler %s: heartbeat sent successfully', self.name)

    @property
    def last_heartbeat(self) -> datetime | None:
        """Return the UTC datetime of the last heartbeat, or None if no heartbeat recorded

        Returns:
            datetime: UTC datetime of the last heartbeat, or None if scheduler not found in registry
        """
        score = self.connection.zscore(cron_scheduler_registry.get_registry_key(), self.name)

        if score is None:
            return None

        # Convert Unix timestamp to UTC datetime
        return datetime.fromtimestamp(score, tz=timezone.utc)


# Global registry to store job data before Cron instance is created
_job_data_registry: list[dict] = []


def register(
    func: Callable,
    queue_name: str,
    args: tuple | None = None,
    kwargs: dict | None = None,
    interval: int | None = None,
    cron: str | None = None,
    job_timeout: int | None = None,
    result_ttl: int = DEFAULT_RESULT_TTL,
    ttl: int | None = None,
    failure_ttl: int | None = None,
    meta: dict | None = None,
    webhooks: Sequence[Webhook] | None = None,
    name: str = '',
) -> dict:
    """
    Register a function to be run as a cron job by adding its definition
    to a temporary global registry.

    This function should typically be called from within a cron configuration file
    that will be loaded using `CronScheduler.load_config_from_file()`.

    Example (in your cron_config.py):
        from rq import cron
        from my_app.tasks import my_func

        cron.register(my_func, 'default', interval=60)  # Run every 60 seconds

    Returns:
        dict: The job data dictionary added to the registry.
    """
    # Store the job data in the global registry
    job_data = {
        'func': func,
        'queue_name': queue_name,
        'args': args,
        'kwargs': kwargs,
        'interval': interval,
        'cron': cron,
        'job_timeout': job_timeout,
        'result_ttl': result_ttl,
        'ttl': ttl,
        'failure_ttl': failure_ttl,
        'meta': meta,
        'webhooks': webhooks,
        'name': name,
    }
    # Add to the global registry
    _job_data_registry.append(job_data)

    # Log the registration attempt (optional)
    logger = logging.getLogger(__name__)
    job_key = f'{func.__module__}.{func.__name__}'
    logger.debug(f"Cron config: Adding job '{job_key}' to registry for queue {queue_name}")

    return job_data


def create_cron(connection: Redis) -> CronScheduler:
    """Create a CronScheduler instance with all registered jobs"""
    cron_instance = CronScheduler(connection=connection)

    # Snapshot and consume the registry so a second call doesn't re-register the same jobs
    job_definitions = _job_data_registry[:]
    _job_data_registry.clear()
    for data in job_definitions:
        logging.debug(f'Registering job: {data["func"].__name__}')
        cron_instance.register(**data)

    return cron_instance
