Describe your issue here.

### Steps to reproduce

Describe how to reproduce the issue. Provide a [fiddle](https://jsfiddle.net) if possible.  
__Note: Please do not provide a full website as example!__

### Environment

- Browser name and version
- mark.js version
