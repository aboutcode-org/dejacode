1.4.0 - Released on 2019-08-19

  * Fixed performance issue with 'withLinks' option
  * Escape double quotes in string values

1.3.0 - Released on 2019-07-04

  * Improved URL detection
  * Fixed XSS injection with 'withLinks' option
  * Fixed JS error when JSON has an attribute 'hasOwnProperty'

1.2.0 - Released on 2019-03-10

  * Added 'rootCollapsable' option
  * Added 'withLinks' option
  * Added 'withQuotes' option
  * Updated to jQuery 3.x
  * Improved style of toggle arrows
  * Fixed JS error in scrict mode

1.1.0 - Released on 2016-02-16

  * Added 'collapsed' option
  * Escape XML/HTML tags in JSON content
  * Made dict key names clickable

1.0.0 - Released on 2015-01-11

  * Initial release
