# Packages

Moved to [pkg project](http://github.com/jrburke/pkg/blob/master/docs/design/packages.md)
