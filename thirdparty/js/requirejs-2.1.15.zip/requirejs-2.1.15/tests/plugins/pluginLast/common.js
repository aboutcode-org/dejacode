define({
    name: 'common'
});
