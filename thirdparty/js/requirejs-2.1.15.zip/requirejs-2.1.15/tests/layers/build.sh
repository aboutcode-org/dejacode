../../build/build.sh baseUrl=../.. name=require out=allplugins-require.js optimize=none
