def(function () {
    return {
        name: 'six'
    };
});