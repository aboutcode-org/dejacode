def(function () {
    return {
        name: 'eight'
    };
});