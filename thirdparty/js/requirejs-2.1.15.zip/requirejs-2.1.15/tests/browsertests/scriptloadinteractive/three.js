def(function () {
    return {
        name: 'three'
    };
});