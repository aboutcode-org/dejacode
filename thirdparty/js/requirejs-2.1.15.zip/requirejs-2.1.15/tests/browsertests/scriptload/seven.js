log("seven.js script");
