define(function(require) {
    return {
        name: 'toolbar',
        template: require('slowText!toolbar.html')
    };
});
