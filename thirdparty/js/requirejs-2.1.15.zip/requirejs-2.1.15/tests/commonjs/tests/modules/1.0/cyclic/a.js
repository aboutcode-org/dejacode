define(["require", "exports", "module", "b"], function(require, exports, module) {
exports.a = function () {
    return b;
};
var b = require('b');

});
