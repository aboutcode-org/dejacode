//A sample module to use in the i18n build test.

define(["i18n!nls/colors"], function (colors) {
   var red = colors.red;
});