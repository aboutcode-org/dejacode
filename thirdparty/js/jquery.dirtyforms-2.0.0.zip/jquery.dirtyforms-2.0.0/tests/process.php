<pre>
<?PHP
var_dump($_POST);
var_dump($_GET);
var_dump($_SERVER);
?>
</pre>
